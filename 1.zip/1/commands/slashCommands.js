const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ChannelType } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('create_message')
        .setDescription('Create custom Message'),

    async execute(interaction, { messages, allowedRoles, saveData, userSessions, config, WIZARD_STEPS }) {
        // Start the creation wizard
        userSessions.set(interaction.user.id, {
            step: WIZARD_STEPS.COLOR,
            userId: interaction.user.id
        });

        const embed = new EmbedBuilder()
            .setColor(config.defaultColor)
            .setTitle('Create Custom Message')
            .setDescription('Set An Embed Colour')
            .setImage(config.images.footerImage)
            .setThumbnail(config.images.thumbnail);

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId(`color_${interaction.user.id}`)
                    .setLabel('Set Colour')
                    .setStyle(ButtonStyle.Primary)
            );

        await interaction.reply({ embeds: [embed], components: [row], ephemeral: true });
    }
};