const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder, StringSelectMenuOptionBuilder, ChannelType } = require('discord.js');
const fs = require('fs');

// List all messages
const messageListCommand = {
    data: new SlashCommandBuilder()
        .setName('message_list')
        .setDescription('List all custom messages'),

    async execute(interaction, { messages, config }) {
        const embed = new EmbedBuilder()
            .setColor(config.defaultColor)
            .setTitle('📝 Messages')
            .setImage(config.images.footerImage)
            .setThumbnail(config.images.thumbnail);

        if (Object.keys(messages).length === 0) {
            embed.setDescription('No messages created yet.');
        } else {
            const messageList = Object.keys(messages).map(cmd => `• \`+${cmd}\``).join('\n');
            embed.setDescription(messageList);
        }

        await interaction.reply({ embeds: [embed], ephemeral: true });
    }
};

// Clone a message
const messageCloneCommand = {
    data: new SlashCommandBuilder()
        .setName('message_clone')
        .setDescription('Clone an existing message')
        .addStringOption(option =>
            option.setName('original')
                .setDescription('Original message to clone')
                .setRequired(true)
                .setAutocomplete(true))
        .addStringOption(option =>
            option.setName('new_name')
                .setDescription('New name for the cloned message')
                .setRequired(true)),

    async autocomplete(interaction) {
        const focusedValue = interaction.options.getFocused();
        const choices = Object.keys(messages);
        const filtered = choices.filter(choice => choice.startsWith(focusedValue)).slice(0, 25);

        await interaction.respond(
            filtered.map(choice => ({ name: `+${choice}`, value: choice }))
        );
    },

    async execute(interaction, { messages, saveData }) {
        const original = interaction.options.getString('original');
        const newName = interaction.options.getString('new_name');

        if (!messages[original]) {
            return interaction.reply({ content: '❌ Original message not found!', ephemeral: true });
        }

        if (messages[newName]) {
            return interaction.reply({ content: '❌ A message with that name already exists!', ephemeral: true });
        }

        // Clone the message
        messages[newName] = {
            ...messages[original],
            createdAt: new Date().toISOString(),
            createdBy: interaction.user.id,
            clonedFrom: original
        };

        saveData();

        await interaction.reply({
            content: `✅ Message \`+${original}\` cloned as \`+${newName}\`!`,
            ephemeral: true
        });
    }
};

// Preview a message
const messagePreviewCommand = {
    data: new SlashCommandBuilder()
        .setName('message_preview')
        .setDescription('Preview a custom message')
        .addStringOption(option =>
            option.setName('name')
                .setDescription('Message to preview')
                .setRequired(true)
                .setAutocomplete(true)),

    async autocomplete(interaction) {
        const focusedValue = interaction.options.getFocused();
        const choices = Object.keys(messages);
        const filtered = choices.filter(choice => choice.startsWith(focusedValue)).slice(0, 25);

        await interaction.respond(
            filtered.map(choice => ({ name: `+${choice}`, value: choice }))
        );
    },

    async execute(interaction, { messages }) {
        const name = interaction.options.getString('name');
        const message = messages[name];

        if (!message) {
            return interaction.reply({ content: '❌ Message not found!', ephemeral: true });
        }

        const embed = new EmbedBuilder()
            .setColor(message.color || config.defaultColor)
            .setTitle(message.title)
            .setDescription(message.description);

        if (message.image) embed.setImage(message.image);
        if (message.thumbnail) embed.setThumbnail(message.thumbnail);
        if (message.footer) embed.setFooter({ text: message.footer });

        // Create buttons if any
        const rows = [];
        if (message.buttons && message.buttons.length > 0) {
            const row = new ActionRowBuilder();

            for (const button of message.buttons.slice(0, 5)) {
                if (button.type === 'link') {
                    row.addComponents(
                        new ButtonBuilder()
                            .setLabel(button.label)
                            .setEmoji(button.emoji || null)
                            .setURL(button.url)
                            .setStyle(ButtonStyle.Link)
                    );
                } else {
                    row.addComponents(
                        new ButtonBuilder()
                            .setCustomId(button.id)
                            .setLabel(button.label)
                            .setEmoji(button.emoji || null)
                            .setStyle(getButtonStyle(button.color))
                    );
                }
            }

            rows.push(row);
        }

        await interaction.reply({ 
            embeds: [embed], 
            components: rows,
            ephemeral: true 
        });
    }
};

// Remove a message
const messageRemoveCommand = {
    data: new SlashCommandBuilder()
        .setName('message_remove')
        .setDescription('Remove a custom message')
        .addStringOption(option =>
            option.setName('name')
                .setDescription('Message to remove')
                .setRequired(true)
                .setAutocomplete(true)),

    async execute(interaction, { messages, saveData }) {
        const name = interaction.options.getString('name');

        if (!messages[name]) {
            return interaction.reply({ content: '❌ Message not found!', ephemeral: true });
        }

        delete messages[name];
        saveData();

        await interaction.reply({
            content: `✅ Message \`+${name}\` has been removed!`,
            ephemeral: true
        });
    }
};

// Edit a message
const messageEditCommand = {
    data: new SlashCommandBuilder()
        .setName('message_edit')
        .setDescription('Edit an existing message')
        .addStringOption(option =>
            option.setName('name')
                .setDescription('Message to edit')
                .setRequired(true)
                .setAutocomplete(true)),

    async execute(interaction, { messages, userSessions, WIZARD_STEPS }) {
        const name = interaction.options.getString('name');
        const message = messages[name];

        if (!message) {
            return interaction.reply({ content: '❌ Message not found!', ephemeral: true });
        }

        // Start edit session
        userSessions.set(interaction.user.id, {
            step: WIZARD_STEPS.COLOR,
            userId: interaction.user.id,
            editing: name,
            ...message
        });

        // Show first step
        const embed = new EmbedBuilder()
            .setColor(config.defaultColor)
            .setTitle('Edit Message')
            .setDescription('Current color: ' + (message.color || 'Not set'))
            .setImage(config.images.footerImage)
            .setThumbnail(config.images.thumbnail);

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId(`color_${interaction.user.id}`)
                    .setLabel('Change Colour')
                    .setStyle(ButtonStyle.Primary)
            );

        await interaction.reply({ embeds: [embed], components: [row], ephemeral: true });
    }
};

// Export messages
const exportMessagesCommand = {
    data: new SlashCommandBuilder()
        .setName('export_messages')
        .setDescription('Export all messages as JSON file'),

    async execute(interaction, { messages }) {
        const json = JSON.stringify(messages, null, 2);
        const buffer = Buffer.from(json, 'utf8');

        await interaction.reply({
            files: [{
                attachment: buffer,
                name: 'messages_export.json'
            }],
            ephemeral: true
        });
    }
};

// Import messages
const importMessagesCommand = {
    data: new SlashCommandBuilder()
        .setName('import_messages')
        .setDescription('Import messages from JSON file')
        .addAttachmentOption(option =>
            option.setName('file')
                .setDescription('JSON file to import')
                .setRequired(true)),

    async execute(interaction, { messages, saveData }) {
        const file = interaction.options.getAttachment('file');

        if (!file.name.endsWith('.json')) {
            return interaction.reply({ content: '❌ Please provide a JSON file!', ephemeral: true });
        }

        try {
            const response = await fetch(file.url);
            const imported = await response.json();

            // Merge imported messages
            Object.assign(messages, imported);
            saveData();

            await interaction.reply({
                content: `✅ Successfully imported ${Object.keys(imported).length} messages!`,
                ephemeral: true
            });
        } catch (error) {
            await interaction.reply({
                content: '❌ Failed to import messages. Please check the file format.',
                ephemeral: true
            });
        }
    }
};

// Clear all messages
const clearMessagesCommand = {
    data: new SlashCommandBuilder()
        .setName('clear_messages')
        .setDescription('Clear all messages (careful)')
        .addStringOption(option =>
            option.setName('confirm')
                .setDescription('Type "confirm" to clear all messages')
                .setRequired(true)),

    async execute(interaction, { messages, saveData }) {
        const confirm = interaction.options.getString('confirm');

        if (confirm.toLowerCase() !== 'confirm') {
            return interaction.reply({ 
                content: '❌ You must type "confirm" to clear all messages!', 
                ephemeral: true 
            });
        }

        const count = Object.keys(messages).length;
        messages = {};
        saveData();

        await interaction.reply({
            content: `✅ Cleared ${count} messages!`,
            ephemeral: true
        });
    }
};

// Allow role
const messageRoleAllowCommand = {
    data: new SlashCommandBuilder()
        .setName('message_role_allow')
        .setDescription('Allow a role to use message commands')
        .addRoleOption(option =>
            option.setName('role')
                .setDescription('Role to allow')
                .setRequired(true)),

    async execute(interaction, { allowedRoles, saveData }) {
        const role = interaction.options.getRole('role');

        if (allowedRoles.includes(role.id)) {
            return interaction.reply({ 
                content: '❌ That role is already allowed!', 
                ephemeral: true 
            });
        }

        allowedRoles.push(role.id);
        saveData();

        await interaction.reply({
            content: `✅ Role ${role.name} can now use message commands!`,
            ephemeral: true
        });
    }
};

// Remove role
const messageRoleRemoveCommand = {
    data: new SlashCommandBuilder()
        .setName('message_role_remove')
        .setDescription('Remove a role from using message commands')
        .addRoleOption(option =>
            option.setName('role')
                .setDescription('Role to remove')
                .setRequired(true)),

    async execute(interaction, { allowedRoles, saveData }) {
        const role = interaction.options.getRole('role');
        const index = allowedRoles.indexOf(role.id);

        if (index === -1) {
            return interaction.reply({ 
                content: '❌ That role is not in the allowed list!', 
                ephemeral: true 
            });
        }

        allowedRoles.splice(index, 1);
        saveData();

        await interaction.reply({
            content: `✅ Role ${role.name} can no longer use message commands!`,
            ephemeral: true
        });
    }
};

// Rename message
const messageRenameCommand = {
    data: new SlashCommandBuilder()
        .setName('message_rename')
        .setDescription('Rename a message command')
        .addStringOption(option =>
            option.setName('old_name')
                .setDescription('Current message name')
                .setRequired(true)
                .setAutocomplete(true))
        .addStringOption(option =>
            option.setName('new_name')
                .setDescription('New message name')
                .setRequired(true)),

    async execute(interaction, { messages, saveData }) {
        const oldName = interaction.options.getString('old_name');
        const newName = interaction.options.getString('new_name');

        if (!messages[oldName]) {
            return interaction.reply({ content: '❌ Message not found!', ephemeral: true });
        }

        if (messages[newName]) {
            return interaction.reply({ content: '❌ A message with that name already exists!', ephemeral: true });
        }

        messages[newName] = messages[oldName];
        delete messages[oldName];
        saveData();

        await interaction.reply({
            content: `✅ Message renamed from \`+${oldName}\` to \`+${newName}\`!`,
            ephemeral: true
        });
    }
};

// Bulk send
const bulkSendCommand = {
    data: new SlashCommandBuilder()
        .setName('bulk_send')
        .setDescription('Send a message to multiple channels')
        .addStringOption(option =>
            option.setName('message_name')
                .setDescription('Message to send')
                .setRequired(true)
                .setAutocomplete(true))
        .addChannelOption(option =>
            option.setName('channel1')
                .setDescription('First channel')
                .addChannelTypes(ChannelType.GuildText))
        .addChannelOption(option =>
            option.setName('channel2')
                .setDescription('Second channel')
                .addChannelTypes(ChannelType.GuildText))
        .addChannelOption(option =>
            option.setName('channel3')
                .setDescription('Third channel')
                .addChannelTypes(ChannelType.GuildText))
        .addChannelOption(option =>
            option.setName('channel4')
                .setDescription('Fourth channel')
                .addChannelTypes(ChannelType.GuildText))
        .addChannelOption(option =>
            option.setName('channel5')
                .setDescription('Fifth channel')
                .addChannelTypes(ChannelType.GuildText)),

    async execute(interaction, { messages }) {
        const name = interaction.options.getString('message_name');
        const message = messages[name];

        if (!message) {
            return interaction.reply({ content: '❌ Message not found!', ephemeral: true });
        }

        const channels = [
            interaction.options.getChannel('channel1'),
            interaction.options.getChannel('channel2'),
            interaction.options.getChannel('channel3'),
            interaction.options.getChannel('channel4'),
            interaction.options.getChannel('channel5')
        ].filter(channel => channel !== null);

        if (channels.length === 0) {
            return interaction.reply({ content: '❌ Please select at least one channel!', ephemeral: true });
        }

        await interaction.reply({ 
            content: `📤 Sending message to ${channels.length} channel(s)...`, 
            ephemeral: true 
        });

        let successCount = 0;
        for (const channel of channels) {
            try {
                const embed = new EmbedBuilder()
                    .setColor(message.color || config.defaultColor)
                    .setTitle(message.title)
                    .setDescription(message.description);

                if (message.image) embed.setImage(message.image);
                if (message.thumbnail) embed.setThumbnail(message.thumbnail);
                if (message.footer) embed.setFooter({ text: message.footer });

                await channel.send({ embeds: [embed] });
                successCount++;
            } catch (error) {
                console.error(`Failed to send to ${channel.name}:`, error);
            }
        }

        await interaction.followUp({
            content: `✅ Successfully sent to ${successCount}/${channels.length} channels!`,
            ephemeral: true
        });
    }
};

// Info command
const infoCommand = {
    data: new SlashCommandBuilder()
        .setName('message_info')
        .setDescription('Get information about a message')
        .addStringOption(option =>
            option.setName('name')
                .setDescription('Message to get info about')
                .setRequired(true)
                .setAutocomplete(true)),

    async execute(interaction, { messages, config }) {
        const name = interaction.options.getString('name');
        const message = messages[name];

        if (!message) {
            return interaction.reply({ content: '❌ Message not found!', ephemeral: true });
        }

        const embed = new EmbedBuilder()
            .setColor(config.defaultColor)
            .setTitle(`ℹ️ Message info:`)
            .setDescription(`**•~+${name}**`)
            .addFields(
                { name: '**Title:**', value: `\`${message.title}\``, inline: false },
                { name: '**Colour:**', value: `\`${message.color || 'Not set'}\``, inline: false },
                { name: '**Description:**', value: `\`${message.description || 'Not set'}\``, inline: false },
                { name: '**Image:**', value: `\`${message.image || 'Not set'}\``, inline: false },
                { name: '**Thumbnail:**', value: `\`${message.thumbnail || 'Not set'}\``, inline: false },
                { name: '**Footer:**', value: `\`${message.footer || 'Not set'}\``, inline: false },
                { name: '**Repeat:**', value: `\`${message.repeat || 'Not set'}\``, inline: false },
                { name: '**Buttons:**', value: `\`${message.buttons?.length || 0}\``, inline: false },
                { name: '**Created by:**', value: `<@${message.createdBy}>`, inline: false },
                { name: '**Created at:**', value: `\`${new Date(message.createdAt).toLocaleString()}\``, inline: false }
            )
            .setImage(config.images.footerImage)
            .setThumbnail(config.images.thumbnail);

        await interaction.reply({ embeds: [embed], ephemeral: true });
    }
};

// Helper function to get button style
function getButtonStyle(color) {
    switch(color?.toLowerCase()) {
        case 'grey': return ButtonStyle.Secondary;
        case 'green': return ButtonStyle.Success;
        case 'red': return ButtonStyle.Danger;
        case 'blue': return ButtonStyle.Primary;
        default: return ButtonStyle.Primary;
    }
}

// Export all commands
module.exports = [
    messageListCommand,
    messageCloneCommand,
    messagePreviewCommand,
    messageRemoveCommand,
    messageEditCommand,
    exportMessagesCommand,
    importMessagesCommand,
    clearMessagesCommand,
    messageRoleAllowCommand,
    messageRoleRemoveCommand,
    messageRenameCommand,
    bulkSendCommand,
    infoCommand
];