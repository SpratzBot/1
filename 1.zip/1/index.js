require('dotenv').config();
const { Client, GatewayIntentBits, Collection, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');
const fs = require('fs');
const path = require('path');

// Data file paths
const blacklistPath = path.join(__dirname, 'data', 'blacklist.json');
const autopurgePath = path.join(__dirname, 'data', 'autopurge.json');
const domainsPath = path.join(__dirname, 'data', 'domains.json');
const staffPath = path.join(__dirname, 'data', 'staff.json');
const bansPath = path.join(__dirname, 'data', 'bans.json');
const welcomePath = path.join(__dirname, 'data', 'welcome.json');
const logsPath = path.join(__dirname, 'data', 'logs.json');

// Auto-purge intervals storage
const autopurgeIntervals = new Map();

// Store bot's autopurge message IDs to prevent them from being deleted
const autopurgeMessageIds = new Map();

function loadBlacklist() {
    if (!fs.existsSync(blacklistPath)) {
        fs.writeFileSync(blacklistPath, JSON.stringify({ words: [], bypassUsers: [], bypassRoles: [], bypassChannels: [] }));
    }
    return JSON.parse(fs.readFileSync(blacklistPath, 'utf8'));
}

function loadAutopurge() {
    if (!fs.existsSync(autopurgePath)) {
        fs.writeFileSync(autopurgePath, JSON.stringify({}));
    }
    return JSON.parse(fs.readFileSync(autopurgePath, 'utf8'));
}

function loadDomains() {
    if (!fs.existsSync(domainsPath)) {
        fs.writeFileSync(domainsPath, JSON.stringify({ domains: [], thumbnail: '', image: '' }));
    }
    return JSON.parse(fs.readFileSync(domainsPath, 'utf8'));
}

function saveDomains(data) {
    fs.writeFileSync(domainsPath, JSON.stringify(data, null, 2));
}

function loadStaff() {
    if (!fs.existsSync(staffPath)) {
        fs.writeFileSync(staffPath, JSON.stringify({ staffRoles: [] }));
    }
    return JSON.parse(fs.readFileSync(staffPath, 'utf8'));
}

function saveStaff(data) {
    fs.writeFileSync(staffPath, JSON.stringify(data, null, 2));
}

function loadBans() {
    if (!fs.existsSync(bansPath)) {
        fs.writeFileSync(bansPath, JSON.stringify({ bans: [] }));
    }
    return JSON.parse(fs.readFileSync(bansPath, 'utf8'));
}

function saveBans(data) {
    fs.writeFileSync(bansPath, JSON.stringify(data, null, 2));
}

function loadWelcome() {
    if (!fs.existsSync(welcomePath)) {
        fs.writeFileSync(welcomePath, JSON.stringify({ enabled: false, channelId: '', title: 'Welcome!', description: 'Welcome to the server!', color: '#a000c8' }));
    }
    return JSON.parse(fs.readFileSync(welcomePath, 'utf8'));
}

function saveWelcome(data) {
    fs.writeFileSync(welcomePath, JSON.stringify(data, null, 2));
}

function loadLogs() {
    if (!fs.existsSync(logsPath)) {
        fs.writeFileSync(logsPath, JSON.stringify({ channelId: '' }));
    }
    return JSON.parse(fs.readFileSync(logsPath, 'utf8'));
}

function saveLogs(data) {
    fs.writeFileSync(logsPath, JSON.stringify(data, null, 2));
}

// Check if user is staff or admin
function isStaffOrAdmin(member) {
    if (member.permissions.has('Administrator')) return true;
    const staff = loadStaff();
    return member.roles.cache.some(role => staff.staffRoles.includes(role.id));
}

// Get user from mention or ID (async - uses fetch instead of cache)
async function getUserFromMentionOrId(message, arg) {
    if (!arg) return null;
    try {
        const mentionMatch = arg.match(/^<@!?(\d+)>$/);
        if (mentionMatch) {
            return await message.guild.members.fetch(mentionMatch[1]);
        }
        if (/^\d+$/.test(arg)) {
            return await message.guild.members.fetch(arg);
        }
    } catch (e) {
        return null;
    }
    return null;
}

// Log command to logs channel
async function logCommand(client, guild, user, commandName, details = '') {
    const logsData = loadLogs();
    if (!logsData.channelId) return;
    
    const channel = guild.channels.cache.get(logsData.channelId);
    if (!channel) return;
    
    const embed = new EmbedBuilder()
        .setColor('#a000c8')
        .setTitle('Command Log')
        .setDescription(`**Command:** \`${commandName}\`\n**User:** ${user.tag} (${user.id})\n${details}`)
        .setTimestamp()
        .setFooter({ text: 'Novaflare Logs' });
    
    try {
        await channel.send({ embeds: [embed] });
    } catch (e) {
        console.error('Failed to log command:', e);
    }
}

// Format time difference
function formatTimeDiff(timestamp) {
    const diff = Date.now() - timestamp;
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    const weeks = Math.floor(days / 7);
    const months = Math.floor(days / 30);
    const years = Math.floor(days / 365);
    
    if (years > 0) return `${years} year${years > 1 ? 's' : ''} ago`;
    if (months > 0) return `${months} month${months > 1 ? 's' : ''} ago`;
    if (weeks > 0) return `${weeks} week${weeks > 1 ? 's' : ''} ago`;
    return `${days} day${days > 1 ? 's' : ''} ago`;
}

// Parse time string (e.g., "1d", "2h", "30m")
function parseTimeString(timeStr) {
    const match = timeStr.match(/^(\d+)(s|m|h|d|w)$/i);
    if (!match) return null;
    
    const value = parseInt(match[1]);
    const unit = match[2].toLowerCase();
    
    switch (unit) {
        case 's': return value * 1000;
        case 'm': return value * 60 * 1000;
        case 'h': return value * 60 * 60 * 1000;
        case 'd': return value * 24 * 60 * 60 * 1000;
        case 'w': return value * 7 * 24 * 60 * 60 * 1000;
        default: return null;
    }
}

// URL detection regex
const urlRegex = /(https?:\/\/[^\s]+)|(www\.[^\s]+)|([a-zA-Z0-9][-a-zA-Z0-9]*\.(com|org|net|io|gg|xyz|co|me|tv|info|biz|app|dev)[^\s]*)/gi;

// Create client instance
const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildBans,
        GatewayIntentBits.GuildModeration
    ]
});

// Load configuration
const config = require('./config.json');

// Load data
const messagesPath = path.join(__dirname, 'data', 'messages.json');
const rolesPath = path.join(__dirname, 'data', 'roles.json');

// Ensure data directory exists
if (!fs.existsSync(path.join(__dirname, 'data'))) {
    fs.mkdirSync(path.join(__dirname, 'data'));
}

// Initialize data files if they don't exist
if (!fs.existsSync(messagesPath)) {
    fs.writeFileSync(messagesPath, JSON.stringify({}));
}
if (!fs.existsSync(rolesPath)) {
    fs.writeFileSync(rolesPath, JSON.stringify({ allowedRoles: [] }));
}

// Load messages and roles
let messages = JSON.parse(fs.readFileSync(messagesPath, 'utf8'));
let allowedRoles = JSON.parse(fs.readFileSync(rolesPath, 'utf8')).allowedRoles || [];

// Store active user sessions
const userSessions = new Map();

// Message creation wizard steps
const WIZARD_STEPS = {
    COLOR: 'color',
    TITLE: 'title',
    DESCRIPTION: 'description',
    IMAGES: 'images',
    FOOTER: 'footer',
    REPEAT: 'repeat',
    BUTTONS: 'buttons',
    COMMAND_NAME: 'command_name'
};

// Helper function to save data
function saveData() {
    fs.writeFileSync(messagesPath, JSON.stringify(messages, null, 2));
    fs.writeFileSync(rolesPath, JSON.stringify({ allowedRoles }, null, 2));
}

// Check if user has permission
function hasPermission(member) {
    if (member.permissions.has('Administrator')) return true;
    return member.roles.cache.some(role => allowedRoles.includes(role.id));
}

// Load commands
client.commands = new Collection();
const commandFiles = fs.readdirSync(path.join(__dirname, 'commands')).filter(file => file.endsWith('.js'));

for (const file of commandFiles) {
    const command = require(path.join(__dirname, 'commands', file));
    if (Array.isArray(command)) {
        for (const cmd of command) {
            client.commands.set(cmd.data.name, cmd);
        }
    } else {
        client.commands.set(command.data.name, command);
    }
}

// Auto-purge function
async function performAutoPurge(channelId, guildId) {
    try {
        const guild = client.guilds.cache.get(guildId);
        if (!guild) return;
        
        const channel = guild.channels.cache.get(channelId);
        if (!channel) return;

        // Get the previous autopurge message ID for this channel
        const previousMessageId = autopurgeMessageIds.get(channelId);

        const startTime = Date.now();
        
        let deleted = 0;
        let fetched;
        do {
            fetched = await channel.messages.fetch({ limit: 100 });
            // Filter messages: must be within 14 days AND not be the bot's autopurge message
            const deletable = fetched.filter(msg => {
                // Don't delete the bot's autopurge status message
                if (previousMessageId && msg.id === previousMessageId) return false;
                // Only delete messages within 14 days (Discord API limitation)
                return Date.now() - msg.createdTimestamp < 14 * 24 * 60 * 60 * 1000;
            });
            if (deletable.size > 0) {
                await channel.bulkDelete(deletable, true);
                deleted += deletable.size;
            }
        } while (fetched.size >= 100);

        const endTime = Date.now();
        const timeTaken = ((endTime - startTime) / 1000).toFixed(2);

        // Delete the previous autopurge message if it exists
        if (previousMessageId) {
            try {
                const oldMessage = await channel.messages.fetch(previousMessageId);
                if (oldMessage) await oldMessage.delete();
            } catch (e) {
                // Message might already be deleted, ignore
            }
        }

        const embed = new EmbedBuilder()
            .setColor('#000001')
            .setTitle('**Auto-Purge Result**')
            .setDescription(`Purge successfully\nTime taken: **${timeTaken}s**\nMessages deleted: **${deleted}**`)
            .setImage('https://cdn.discordapp.com/attachments/1442093639822999572/1442154889722597386/844f7e76c6e1eeb8266be6b17362b385.gif');

        // Send new status message and store its ID
        const sentMessage = await channel.send({ embeds: [embed] });
        autopurgeMessageIds.set(channelId, sentMessage.id);
    } catch (error) {
        console.error('Auto-purge error:', error);
    }
}

// Start auto-purge intervals
function startAutoPurgeIntervals() {
    const autopurge = loadAutopurge();
    
    for (const [channelId, config] of Object.entries(autopurge)) {
        if (autopurgeIntervals.has(channelId)) {
            clearInterval(autopurgeIntervals.get(channelId));
        }
        
        const interval = setInterval(() => {
            performAutoPurge(channelId, config.guildId);
        }, config.interval);
        
        autopurgeIntervals.set(channelId, interval);
        console.log(`📋 Auto-purge scheduled for channel ${channelId} every ${config.timeString}`);
    }
}

// Clear a specific auto-purge interval
function clearAutoPurgeInterval(channelId) {
    if (autopurgeIntervals.has(channelId)) {
        clearInterval(autopurgeIntervals.get(channelId));
        autopurgeIntervals.delete(channelId);
        console.log(`📋 Auto-purge removed for channel ${channelId}`);
    }
}

// Bot ready event
client.once('ready', () => {
    console.log(`✅ Logged in as ${client.user.tag}!`);
    console.log(`📊 ${Object.keys(messages).length} messages loaded`);
    startAutoPurgeIntervals();
});

// Welcome message on member join
client.on('guildMemberAdd', async member => {
    try {
        const welcomeData = loadWelcome();
        if (!welcomeData.enabled || !welcomeData.channelId) return;
        
        const channel = member.guild.channels.cache.get(welcomeData.channelId);
        if (!channel) return;
        
        const title = welcomeData.title
            .replace(/{user}/g, member.user.username)
            .replace(/{server}/g, member.guild.name)
            .replace(/{memberCount}/g, member.guild.memberCount);
        
        const description = welcomeData.description
            .replace(/{user}/g, `<@${member.user.id}>`)
            .replace(/{server}/g, member.guild.name)
            .replace(/{memberCount}/g, member.guild.memberCount);
        
        const embed = new EmbedBuilder()
            .setColor(welcomeData.color || '#a000c8')
            .setTitle(title)
            .setDescription(description)
            .setThumbnail(member.user.displayAvatarURL({ dynamic: true, size: 256 }))
            .setFooter({ text: `Member #${member.guild.memberCount}` })
            .setTimestamp();
        
        await channel.send({ embeds: [embed] });
    } catch (e) {
        console.error('Welcome message error:', e);
    }
});

// Interaction handling
client.on('interactionCreate', async interaction => {
    // Handle slash commands
    if (interaction.isChatInputCommand()) {
        const command = client.commands.get(interaction.commandName);

        if (!command) return;

        try {
            // Admin-only commands for message management (create, edit, delete, etc.)
            const adminOnlyMessageCommands = [
                'create_message',
                'message_remove',
                'message_edit',
                'message_clone',
                'message_rename',
                'clear_messages',
                'import_messages',
                'export_messages',
                'message_role_allow',
                'message_role_remove',
                'bulk_send'
            ];
            
            // Check permissions for admin-only message management commands
            if (adminOnlyMessageCommands.includes(interaction.commandName)) {
                if (!hasPermission(interaction.member)) {
                    return interaction.reply({ 
                        content: '❌ You do not have permission to use this command.', 
                        ephemeral: true 
                    });
                }
            }

            await command.execute(interaction, { 
                messages, 
                allowedRoles, 
                saveData, 
                userSessions,
                config,
                WIZARD_STEPS,
                startAutoPurgeIntervals,
                clearAutoPurgeInterval
            });
        } catch (error) {
            console.error(error);
            try {
                if (interaction.replied || interaction.deferred) {
                    await interaction.followUp({ 
                        content: 'There was an error executing this command!', 
                        ephemeral: true 
                    });
                } else {
                    await interaction.reply({ 
                        content: 'There was an error executing this command!', 
                        ephemeral: true 
                    });
                }
            } catch (e) {
                console.error('Failed to send error message:', e);
            }
        }
    }

    // Handle buttons
    else if (interaction.isButton()) {
        await handleButton(interaction);
    }

    // Handle modal submissions
    else if (interaction.isModalSubmit()) {
        await handleModal(interaction);
    }
});

// Button handler
async function handleButton(interaction) {
    const customIdParts = interaction.customId.split('_');
    
    // Handle stats buttons: stats_action_targetUserId_requesterId
    if (customIdParts[0] === 'stats') {
        const [, buttonAction, targetUserId, requesterId] = customIdParts;
        
        // Only the requester can use the buttons
        if (requesterId !== interaction.user.id) {
            return interaction.reply({ 
                content: 'This interaction is not for you!', 
                ephemeral: true 
            });
        }
        
        await handleStatsButton(interaction, buttonAction, targetUserId);
        return;
    }
    
    const [action, userId, step] = customIdParts;

    if (userId !== interaction.user.id) {
        return interaction.reply({ 
            content: 'This interaction is not for you!', 
            ephemeral: true 
        });
    }

    const session = userSessions.get(userId);
    if (!session) {
        return interaction.reply({ 
            content: 'Your session has expired. Please start over.', 
            ephemeral: true 
        });
    }

    switch(action) {
        case 'color':
        case 'title':
        case 'description':
        case 'footer':
        case 'repeat':
            await showModalForStep(interaction, step || action);
            break;
        case 'image':
        case 'thumbnail':
        case 'skip':
        case 'addbutton':
        case 'addlink':
        case 'submit':
            await handleWizardAction(interaction, action, session);
            break;
    }
}

// Stats button handler
async function handleStatsButton(interaction, buttonAction, targetUserId) {
    try {
        const targetUser = await interaction.client.users.fetch(targetUserId);
        
        if (buttonAction === 'download') {
            // Fetch stats and send as a text file
            await interaction.deferReply({ ephemeral: true });
            
            const response = await fetch(`https://api.injuries.lu/v1/public/user?userId=${targetUserId}`);
            const data = await response.json();
            
            if (!data.success) {
                return interaction.editReply({ content: 'Failed to fetch stats data.' });
            }
            
            const highest = data.Normal?.Highest || {};
            const totals = data.Normal?.Totals || {};
            
            const statsText = `=== STATS FOR ${targetUser.username} ===\n\n` +
                `TOTAL STATS:\n` +
                `  Hits: ${totals.Accounts || 0}\n` +
                `  Visits: ${totals.Visits || 0}\n` +
                `  Clicks: ${totals.Clicks || 0}\n\n` +
                `BIGGEST HITS:\n` +
                `  Summary: ${highest.Summary || 0}\n` +
                `  RAP: ${highest.Rap || 0}\n` +
                `  Robux: ${highest.Balance || 0}\n\n` +
                `TOTAL HIT STATS:\n` +
                `  Summary: ${totals.Summary || 0}\n` +
                `  RAP: ${totals.Rap || 0}\n` +
                `  Robux: ${totals.Balance || 0}\n\n` +
                `Generated: ${new Date().toISOString()}`;
            
            const buffer = Buffer.from(statsText, 'utf8');
            const attachment = { attachment: buffer, name: `${targetUser.username}_stats.txt` };
            
            return interaction.editReply({ 
                content: '<a:novaflare_check:1446514493210497045> Here are the stats!', 
                files: [attachment] 
            });
        }
        
        if (buttonAction === 'profile') {
            // Show user profile info
            const embed = new EmbedBuilder()
                .setColor('#a000c8')
                .setTitle(`<a:crown_grey:1447589122603487293> ${targetUser.username}'s Profile`)
                .setThumbnail(targetUser.displayAvatarURL({ dynamic: true, size: 512 }))
                .setDescription(
                    `**<a:novaflare_star:1446514209411043328> User Information**\n` +
                    `<a:Uzi_yee:1447588797780070401> Username: **${targetUser.username}**\n` +
                    `<a:Uzi_yee:1447588797780070401> ID: **${targetUser.id}**\n` +
                    `<a:Uzi_yee:1447588797780070401> Created: **${formatTimeDiff(targetUser.createdTimestamp)}**\n` +
                    `<a:Uzi_yee:1447588797780070401> Bot: **${targetUser.bot ? 'Yes' : 'No'}**`
                )
                .setImage('https://cdn.discordapp.com/attachments/1442093639822999572/1446770827893674097/images_1.jpg')
                .setFooter({ text: 'Novaflare', iconURL: interaction.client.user.displayAvatarURL() })
                .setTimestamp();
            
            return interaction.reply({ embeds: [embed], ephemeral: true });
        }
        
        if (buttonAction === 'refresh') {
            // Refresh stats
            await interaction.deferUpdate();
            
            const response = await fetch(`https://api.injuries.lu/v1/public/user?userId=${targetUserId}`);
            const data = await response.json();
            
            if (!data.success) {
                return interaction.followUp({ content: 'Failed to refresh stats.', ephemeral: true });
            }
            
            const formatNumber = (num) => {
                if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
                if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
                return num.toString();
            };
            
            const highest = data.Normal?.Highest || {};
            const totals = data.Normal?.Totals || {};
            
            const embed = new EmbedBuilder()
                .setColor('#a000c8')
                .setAuthor({ 
                    name: targetUser.username, 
                    iconURL: targetUser.displayAvatarURL({ dynamic: true }) 
                })
                .setTitle('─── ⋆⋅ꜱᴛᴀᴛꜱ ⋅⋆ ───')
                .setDescription(
                    `**<a:novaflare_star:1446514209411043328> TOTAL STATS**\n` +
                    `<a:Uzi_yee:1447588797780070401> Hits: **${formatNumber(totals.Accounts || 0)}**\n` +
                    `<a:Uzi_yee:1447588797780070401> Visits: **${formatNumber(totals.Visits || 0)}**\n` +
                    `<a:Uzi_yee:1447588797780070401> Clicks: **${formatNumber(totals.Clicks || 0)}**\n` +
                    `**<a:novaflare_star:1446514209411043328> BIGGEST HITS**\n` +
                    `<a:Uzi_yee:1447588797780070401> Summary: **${formatNumber(highest.Summary || 0)}**\n` +
                    `<a:Uzi_yee:1447588797780070401> RAP: **${formatNumber(highest.Rap || 0)}**\n` +
                    `<a:Uzi_yee:1447588797780070401> Robux: **${formatNumber(highest.Balance || 0)}**\n` +
                    `**<a:novaflare_star:1446514209411043328> TOTAL HIT STATS**\n` +
                    `<a:Uzi_yee:1447588797780070401> Summary: **${formatNumber(totals.Summary || 0)}**\n` +
                    `<a:Uzi_yee:1447588797780070401> RAP: **${formatNumber(totals.Rap || 0)}**\n` +
                    `<a:Uzi_yee:1447588797780070401> Robux: **${formatNumber(totals.Balance || 0)}**`
                )
                .setThumbnail(targetUser.displayAvatarURL({ dynamic: true, size: 256 }))
                .setImage('https://cdn.discordapp.com/attachments/1442093639822999572/1446770827893674097/images_1.jpg')
                .setFooter({ text: `Refreshed by ${interaction.user.username}`, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) })
                .setTimestamp();

            const statsRow = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId(`stats_download_${targetUserId}_${interaction.user.id}`)
                        .setLabel('Download Stats')
                        .setEmoji('<a:novaflare_fire:1446513689858543707>')
                        .setStyle(ButtonStyle.Primary),
                    new ButtonBuilder()
                        .setCustomId(`stats_profile_${targetUserId}_${interaction.user.id}`)
                        .setLabel('View Profile')
                        .setEmoji('<a:novaflare_check:1446514493210497045>')
                        .setStyle(ButtonStyle.Secondary),
                    new ButtonBuilder()
                        .setCustomId(`stats_refresh_${targetUserId}_${interaction.user.id}`)
                        .setLabel('Refresh')
                        .setEmoji('<a:crown_grey:1447589122603487293>')
                        .setStyle(ButtonStyle.Success)
                );

            return interaction.editReply({ embeds: [embed], components: [statsRow] });
        }
    } catch (error) {
        console.error('Stats button error:', error);
        return interaction.reply({ 
            content: 'An error occurred while processing your request.', 
            ephemeral: true 
        });
    }
}

// Modal handler
async function handleModal(interaction) {
    const [action, userId] = interaction.customId.split('_');

    const session = userSessions.get(userId);
    if (!session) {
        return interaction.reply({ 
            content: 'Your session has expired. Please start over.', 
            ephemeral: true 
        });
    }

    switch(action) {
        case 'color':
            session.color = interaction.fields.getTextInputValue('color');
            await showTitleStep(interaction, session);
            break;
        case 'title':
            session.title = interaction.fields.getTextInputValue('title');
            await showDescriptionStep(interaction, session);
            break;
        case 'description':
            session.description = interaction.fields.getTextInputValue('description');
            await showImagesStep(interaction, session);
            break;
        case 'footer':
            session.footer = interaction.fields.getTextInputValue('footer');
            await showRepeatStep(interaction, session);
            break;
        case 'repeat':
            session.repeat = parseInt(interaction.fields.getTextInputValue('repeat'));
            await showButtonsStep(interaction, session);
            break;
        case 'button':
            const buttonName = interaction.fields.getTextInputValue('buttonName');
            const emoji = interaction.fields.getTextInputValue('emoji');
            const buttonDescription = interaction.fields.getTextInputValue('description');
            const color = interaction.fields.getTextInputValue('color');

            session.buttons = session.buttons || [];
            session.buttons.push({
                type: 'action',
                label: buttonName,
                emoji: emoji || null,
                description: buttonDescription,
                color: color,
                id: `btn_${session.buttons.length + 1}`
            });

            await showButtonsStep(interaction, session);
            break;
        case 'link':
            const linkName = interaction.fields.getTextInputValue('buttonName');
            const linkEmoji = interaction.fields.getTextInputValue('emoji');
            const url = interaction.fields.getTextInputValue('url');

            session.buttons = session.buttons || [];
            session.buttons.push({
                type: 'link',
                label: linkName,
                emoji: linkEmoji || null,
                url: url,
                id: `link_${session.buttons.length + 1}`
            });

            await showButtonsStep(interaction, session);
            break;
        case 'commandname':
            let commandName = interaction.fields.getTextInputValue('commandName');
            // Remove leading + if user included it
            if (commandName.startsWith('+')) {
                commandName = commandName.slice(1);
            }
            commandName = commandName.toLowerCase().trim();

            // Validate command name is not empty
            if (!commandName || commandName.length === 0) {
                return interaction.reply({
                    content: '❌ Please enter a valid command name (not just "+")!',
                    ephemeral: true
                });
            }

            // Save the message
            messages[commandName] = {
                title: session.title || 'No Title',
                description: session.description || 'No Description',
                color: session.color || config.defaultColor,
                image: session.image || null,
                thumbnail: session.thumbnail || null,
                footer: session.footer || null,
                repeat: session.repeat || null,
                buttons: session.buttons || [],
                createdAt: new Date().toISOString(),
                createdBy: interaction.user.id
            };

            saveData();
            userSessions.delete(userId);

            await interaction.reply({
                content: `✅ Message saved as \`+${commandName}\`!`,
                ephemeral: true
            });
            break;
    }
}

// Wizard step functions
async function showModalForStep(interaction, step) {
    const modal = new ModalBuilder()
        .setCustomId(`${step}_${interaction.user.id}`)
        .setTitle(`Set ${step.charAt(0).toUpperCase() + step.slice(1)}`);

    const input = new TextInputBuilder()
        .setCustomId(step)
        .setLabel(step === 'color' ? 'Hex Color' : step.charAt(0).toUpperCase() + step.slice(1))
        .setStyle(TextInputStyle.Short);

    switch(step) {
        case 'color':
            input.setValue('#000000');
            break;
        case 'repeat':
            input.setValue('60');
            modal.setTitle('Set Repeat Time');
            input.setLabel('Time in seconds');
            break;
    }

    modal.addComponents(new ActionRowBuilder().addComponents(input));

    await interaction.showModal(modal);
}

async function showTitleStep(interaction, session) {
    const embed = new EmbedBuilder()
        .setColor(config.defaultColor)
        .setTitle('Customise Title')
        .setDescription('Set The Title of your Message');

    const row = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId(`title_${interaction.user.id}`)
                .setLabel('Set Title')
                .setStyle(ButtonStyle.Primary)
        );

    await interaction.update({ embeds: [embed], components: [row] });
}

async function showDescriptionStep(interaction, session) {
    const embed = new EmbedBuilder()
        .setColor(config.defaultColor)
        .setTitle('Customise Description')
        .setDescription('Set Description of Custom Message');

    const row = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId(`description_${interaction.user.id}`)
                .setLabel('Set Description')
                .setStyle(ButtonStyle.Primary)
        );

    await interaction.update({ embeds: [embed], components: [row] });
}

async function showImagesStep(interaction, session) {
    const embed = new EmbedBuilder()
        .setColor(config.defaultColor)
        .setTitle('Image & Thumbnail')
        .setDescription('Set URLs or Skip');

    const row = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId(`image_${interaction.user.id}`)
                .setLabel('Image')
                .setStyle(ButtonStyle.Primary),
            new ButtonBuilder()
                .setCustomId(`thumbnail_${interaction.user.id}_1`)
                .setLabel('Thumbnail 1')
                .setStyle(ButtonStyle.Primary),
            new ButtonBuilder()
                .setCustomId(`skip_${interaction.user.id}_images`)
                .setLabel('Skip')
                .setStyle(ButtonStyle.Secondary)
        );

    await interaction.update({ embeds: [embed], components: [row] });
}

async function showFooterStep(interaction, session) {
    const embed = new EmbedBuilder()
        .setColor(config.defaultColor)
        .setTitle('Customise Footer')
        .setDescription('Set Footer or Skip')
        .setImage(config.images.footerImage)
        .setThumbnail(config.images.thumbnail);

    const row = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId(`footer_${interaction.user.id}`)
                .setLabel('Set Footer')
                .setStyle(ButtonStyle.Primary),
            new ButtonBuilder()
                .setCustomId(`skip_${interaction.user.id}_footer`)
                .setLabel('Skip')
                .setStyle(ButtonStyle.Secondary)
        );

    await interaction.update({ embeds: [embed], components: [row] });
}

async function showRepeatStep(interaction, session) {
    const embed = new EmbedBuilder()
        .setColor(config.defaultColor)
        .setTitle('Repeat?')
        .setDescription('Would you like this message to repeat?')
        .setImage(config.images.footerImage)
        .setThumbnail(config.images.thumbnail);

    const row = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId(`repeat_${interaction.user.id}`)
                .setLabel('Yes')
                .setStyle(ButtonStyle.Success),
            new ButtonBuilder()
                .setCustomId(`skip_${interaction.user.id}_repeat`)
                .setLabel('No')
                .setStyle(ButtonStyle.Secondary)
        );

    await interaction.update({ embeds: [embed], components: [row] });
}

async function showButtonsStep(interaction, session) {
    const embed = new EmbedBuilder()
        .setColor(config.defaultColor)
        .setTitle('Customise Buttons')
        .setDescription(`Current: ${session.buttons?.length || 0}`)
        .setImage(config.images.footerImage)
        .setThumbnail(config.images.thumbnail);

    const row = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId(`addbutton_${interaction.user.id}`)
                .setLabel(`Add Button ${(session.buttons?.length || 0) + 1}`)
                .setStyle(ButtonStyle.Primary),
            new ButtonBuilder()
                .setCustomId(`addlink_${interaction.user.id}`)
                .setLabel(`Add Link ${(session.buttons?.length || 0) + 1}`)
                .setStyle(ButtonStyle.Primary),
            new ButtonBuilder()
                .setCustomId(`submit_${interaction.user.id}`)
                .setLabel('Submit')
                .setStyle(ButtonStyle.Success)
        );

    await interaction.update({ embeds: [embed], components: [row] });
}

async function handleWizardAction(interaction, action, session) {
    switch(action) {
        case 'image':
            session.image = await promptForInput(interaction, 'image', 'Image URL', 'Enter image URL');
            break;
        case 'thumbnail':
            const thumbNum = parseInt(interaction.customId.split('_')[2]);
            session.thumbnail = session.thumbnail || [];
            session.thumbnail[thumbNum - 1] = await promptForInput(interaction, 'thumbnail', 'Thumbnail URL', 'Enter thumbnail URL');

            if (thumbNum < 3) {
                const embed = new EmbedBuilder()
                    .setColor(config.defaultColor)
                    .setTitle('Image & Thumbnail')
                    .setDescription('Set URLs or Skip');

                const row = new ActionRowBuilder()
                    .addComponents(
                        new ButtonBuilder()
                            .setCustomId(`image_${interaction.user.id}`)
                            .setLabel('Image')
                            .setStyle(ButtonStyle.Primary),
                        new ButtonBuilder()
                            .setCustomId(`thumbnail_${interaction.user.id}_${thumbNum + 1}`)
                            .setLabel(`Thumbnail ${thumbNum + 1}`)
                            .setStyle(ButtonStyle.Primary),
                        new ButtonBuilder()
                            .setCustomId(`skip_${interaction.user.id}_images`)
                            .setLabel('Skip')
                            .setStyle(ButtonStyle.Secondary)
                    );

                await interaction.update({ embeds: [embed], components: [row] });
            } else {
                await showFooterStep(interaction, session);
            }
            break;
        case 'skip':
            const skipType = interaction.customId.split('_')[2];
            if (skipType === 'images') {
                await showFooterStep(interaction, session);
            } else if (skipType === 'footer') {
                await showRepeatStep(interaction, session);
            } else if (skipType === 'repeat') {
                await showButtonsStep(interaction, session);
            }
            break;
        case 'addbutton':
            await showButtonModal(interaction);
            break;
        case 'addlink':
            await showLinkModal(interaction);
            break;
        case 'submit':
            await showCommandNameModal(interaction);
            break;
    }
}

async function promptForInput(interaction, type, label, placeholder) {
    const modal = new ModalBuilder()
        .setCustomId(`${type}_${interaction.user.id}`)
        .setTitle(`Set ${label}`);

    const input = new TextInputBuilder()
        .setCustomId(type)
        .setLabel(label)
        .setPlaceholder(placeholder)
        .setStyle(TextInputStyle.Short);

    modal.addComponents(new ActionRowBuilder().addComponents(input));

    await interaction.showModal(modal);

    // This is a simplified version - in production you'd need to handle the modal response
    return new Promise((resolve) => {
        // You'd set up an event listener for the modal response
        // For now, we'll return a placeholder
        resolve('');
    });
}

async function showButtonModal(interaction) {
    const modal = new ModalBuilder()
        .setCustomId(`button_${interaction.user.id}`)
        .setTitle('Add Button');

    const buttonName = new TextInputBuilder()
        .setCustomId('buttonName')
        .setLabel('Button Name')
        .setStyle(TextInputStyle.Short);

    const emoji = new TextInputBuilder()
        .setCustomId('emoji')
        .setLabel('Emoji')
        .setStyle(TextInputStyle.Short)
        .setRequired(false);

    const description = new TextInputBuilder()
        .setCustomId('description')
        .setLabel('Description')
        .setStyle(TextInputStyle.Paragraph);

    const color = new TextInputBuilder()
        .setCustomId('color')
        .setLabel('Color (grey/blue/green/red)')
        .setStyle(TextInputStyle.Short);

    modal.addComponents(
        new ActionRowBuilder().addComponents(buttonName),
        new ActionRowBuilder().addComponents(emoji),
        new ActionRowBuilder().addComponents(description),
        new ActionRowBuilder().addComponents(color)
    );

    await interaction.showModal(modal);
}

async function showLinkModal(interaction) {
    const modal = new ModalBuilder()
        .setCustomId(`link_${interaction.user.id}`)
        .setTitle('Add Link Button');

    const buttonName = new TextInputBuilder()
        .setCustomId('buttonName')
        .setLabel('Button Name')
        .setStyle(TextInputStyle.Short);

    const emoji = new TextInputBuilder()
        .setCustomId('emoji')
        .setLabel('Emoji')
        .setStyle(TextInputStyle.Short)
        .setRequired(false);

    const url = new TextInputBuilder()
        .setCustomId('url')
        .setLabel('URL')
        .setStyle(TextInputStyle.Short)
        .setValue('https://example.com');

    modal.addComponents(
        new ActionRowBuilder().addComponents(buttonName),
        new ActionRowBuilder().addComponents(emoji),
        new ActionRowBuilder().addComponents(url)
    );

    await interaction.showModal(modal);
}

async function showCommandNameModal(interaction) {
    const modal = new ModalBuilder()
        .setCustomId(`commandname_${interaction.user.id}`)
        .setTitle('Set Command Name');

    const commandName = new TextInputBuilder()
        .setCustomId('commandName')
        .setLabel('Command Name')
        .setStyle(TextInputStyle.Short)
        .setValue('+');

    modal.addComponents(new ActionRowBuilder().addComponents(commandName));

    await interaction.showModal(modal);
}

// Check if user bypasses blacklist
function hasBypass(message, blacklist) {
    if (blacklist.bypassUsers.includes(message.author.id)) return true;
    if (blacklist.bypassChannels.includes(message.channel.id)) return true;
    if (message.member && message.member.roles.cache.some(role => blacklist.bypassRoles.includes(role.id))) return true;
    if (message.member && message.member.permissions.has('Administrator')) return true;
    return false;
}

// Handle all messages
client.on('messageCreate', async message => {
    if (message.author.bot) return;
    if (!message.guild) return;

    const blacklist = loadBlacklist();
    const messageContent = message.content.toLowerCase();

    if (!hasBypass(message, blacklist)) {
        const hasLink = urlRegex.test(message.content);
        urlRegex.lastIndex = 0;

        if (hasLink) {
            try {
                await message.delete();
                const embed = new EmbedBuilder()
                    .setColor('#000001')
                    .setTitle('🚫 Links Not Allowed')
                    .setDescription("Why'd you do that?")
                    .setImage('https://cdn.discordapp.com/attachments/1442093639822999572/1446522983764992112/b98f92b7f5d87aca06a9e1a2bdbec068.gif');
                try {
                    await message.author.send({ embeds: [embed] });
                } catch (e) {
                    console.error('Could not DM user:', e);
                }
                return;
            } catch (error) {
                console.error('Error handling link:', error);
            }
        }

        for (const word of blacklist.words) {
            if (messageContent.includes(word.toLowerCase())) {
                try {
                    await message.delete();
                    const embed = new EmbedBuilder()
                        .setColor('#000001')
                        .setTitle('🚫 Blacklisted Word Detected')
                        .setDescription("Your message contained a blacklisted word and was removed.")
                        .setImage('https://cdn.discordapp.com/attachments/1442093639822999572/1446522983764992112/b98f92b7f5d87aca06a9e1a2bdbec068.gif');
                    try {
                        await message.author.send({ embeds: [embed] });
                    } catch (e) {
                        console.error('Could not DM user:', e);
                    }
                    return;
                } catch (error) {
                    console.error('Error handling blacklisted word:', error);
                }
            }
        }
    }

    if (!message.content.startsWith('+')) return;

    const commandName = message.content.slice(1).split(' ')[0].toLowerCase();

    // Handle +stats command
    if (commandName === 'stats') {
        const mentionedUser = message.mentions.users.first();
        
        if (!mentionedUser) {
            const embed = new EmbedBuilder()
                .setColor('#a000c8')
                .setTitle('**❌ Error**')
                .setDescription('Please mention a user! Usage: `+stats @user`')
                .setImage('https://cdn.discordapp.com/attachments/1442093639822999572/1446770767906996359/purple-anime-498-x-275-gif-aqa2h5dv1g168tz1.gif');
            return message.channel.send({ embeds: [embed] });
        }

        try {
            const response = await fetch(`https://api.injuries.lu/v1/public/user?userId=${mentionedUser.id}`);
            const data = await response.json();

            if (!data.success) {
                if (data.message === 'User does not exist') {
                    const embed = new EmbedBuilder()
                        .setColor('#a000c8')
                        .setTitle('**❌ Error Code 404**')
                        .setDescription('Api output: {"User does not exist"}')
                        .setImage('https://cdn.discordapp.com/attachments/1442093639822999572/1446770767906996359/purple-anime-498-x-275-gif-aqa2h5dv1g168tz1.gif');
                    return message.channel.send({ embeds: [embed] });
                } else {
                    const embed = new EmbedBuilder()
                        .setColor('#a000c8')
                        .setTitle('**❌ Error Code 404**')
                        .setDescription('Api output: {"Api Error 404"}')
                        .setImage('https://cdn.discordapp.com/attachments/1442093639822999572/1446770767906996359/purple-anime-498-x-275-gif-aqa2h5dv1g168tz1.gif');
                    return message.channel.send({ embeds: [embed] });
                }
            }

            // Format numbers nicely (e.g., 15300 -> 15.3K)
            const formatNumber = (num) => {
                if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
                if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
                return num.toString();
            };

            // Extract data from API response
            const highest = data.Normal?.Highest || {};
            const totals = data.Normal?.Totals || {};

            const embed = new EmbedBuilder()
                .setColor('#a000c8')
                .setAuthor({ 
                    name: mentionedUser.username, 
                    iconURL: mentionedUser.displayAvatarURL({ dynamic: true }) 
                })
                .setTitle('─── ⋆⋅ꜱᴛᴀᴛꜱ ⋅⋆ ───')
                .setDescription(
                    `**<a:novaflare_star:1446514209411043328> TOTAL STATS**\n` +
                    `<a:Uzi_yee:1447588797780070401> Hits: **${formatNumber(totals.Accounts || 0)}**\n` +
                    `<a:Uzi_yee:1447588797780070401> Visits: **${formatNumber(totals.Visits || 0)}**\n` +
                    `<a:Uzi_yee:1447588797780070401> Clicks: **${formatNumber(totals.Clicks || 0)}**\n` +
                    `**<a:novaflare_star:1446514209411043328> BIGGEST HITS**\n` +
                    `<a:Uzi_yee:1447588797780070401> Summary: **${formatNumber(highest.Summary || 0)}**\n` +
                    `<a:Uzi_yee:1447588797780070401> RAP: **${formatNumber(highest.Rap || 0)}**\n` +
                    `<a:Uzi_yee:1447588797780070401> Robux: **${formatNumber(highest.Balance || 0)}**\n` +
                    `**<a:novaflare_star:1446514209411043328> TOTAL HIT STATS**\n` +
                    `<a:Uzi_yee:1447588797780070401> Summary: **${formatNumber(totals.Summary || 0)}**\n` +
                    `<a:Uzi_yee:1447588797780070401> RAP: **${formatNumber(totals.Rap || 0)}**\n` +
                    `<a:Uzi_yee:1447588797780070401> Robux: **${formatNumber(totals.Balance || 0)}**`
                )
                .setThumbnail(mentionedUser.displayAvatarURL({ dynamic: true, size: 256 }))
                .setImage('https://cdn.discordapp.com/attachments/1442093639822999572/1446770827893674097/images_1.jpg')
                .setFooter({ text: `Requested by ${message.author.username}`, iconURL: message.author.displayAvatarURL({ dynamic: true }) })
                .setTimestamp();

            const statsRow = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId(`stats_download_${mentionedUser.id}_${message.author.id}`)
                        .setLabel('Download Stats')
                        .setEmoji('<a:novaflare_fire:1446513689858543707>')
                        .setStyle(ButtonStyle.Primary),
                    new ButtonBuilder()
                        .setCustomId(`stats_profile_${mentionedUser.id}_${message.author.id}`)
                        .setLabel('View Profile')
                        .setEmoji('<a:novaflare_check:1446514493210497045>')
                        .setStyle(ButtonStyle.Secondary),
                    new ButtonBuilder()
                        .setCustomId(`stats_refresh_${mentionedUser.id}_${message.author.id}`)
                        .setLabel('Refresh')
                        .setEmoji('<a:crown_grey:1447589122603487293>')
                        .setStyle(ButtonStyle.Success)
                );

            return message.channel.send({ embeds: [embed], components: [statsRow] });
        } catch (error) {
            console.error('Stats API error:', error);
            const embed = new EmbedBuilder()
                .setColor('#a000c8')
                .setTitle('**❌ Error Code 404**')
                .setDescription('Api output: {"Api Error 404"}')
                .setImage('https://cdn.discordapp.com/attachments/1442093639822999572/1446770767906996359/purple-anime-498-x-275-gif-aqa2h5dv1g168tz1.gif');
            return message.channel.send({ embeds: [embed] });
        }
    }

    // +domains_setup command (admin only)
    if (commandName === 'domains_setup') {
        if (!message.member.permissions.has('Administrator')) {
            const embed = new EmbedBuilder()
                .setColor('#a000c8')
                .setTitle('**❌ Permission Denied**')
                .setDescription('Only administrators can use this command.')
                .setImage('https://cdn.discordapp.com/attachments/1442093639822999572/1446770767906996359/purple-anime-498-x-275-gif-aqa2h5dv1g168tz1.gif');
            return message.channel.send({ embeds: [embed] });
        }
        
        const args = message.content.slice('+domains_setup'.length + 1).trim().split('|').map(s => s.trim());
        if (args.length < 1 || !args[0]) {
            const embed = new EmbedBuilder()
                .setColor('#a000c8')
                .setTitle('**❌ Invalid Usage**')
                .setDescription('Usage: `+domains_setup <domain> | <thumbnail_url> | <image_url>`\nExample: `+domains_setup example.com | https://i.imgur.com/thumb.png | https://i.imgur.com/image.png`')
                .setImage('https://cdn.discordapp.com/attachments/1442093639822999572/1446770767906996359/purple-anime-498-x-275-gif-aqa2h5dv1g168tz1.gif');
            return message.channel.send({ embeds: [embed] });
        }
        
        const domainsData = loadDomains();
        const newDomain = args[0];
        const thumbnail = args[1] || '';
        const image = args[2] || '';
        
        if (domainsData.domains.some(d => d.domain === newDomain)) {
            const embed = new EmbedBuilder()
                .setColor('#a000c8')
                .setTitle('**❌ Domain Exists**')
                .setDescription(`The domain \`${newDomain}\` already exists. Use \`+domain_edit\` to modify it.`)
                .setImage('https://cdn.discordapp.com/attachments/1442093639822999572/1446770767906996359/purple-anime-498-x-275-gif-aqa2h5dv1g168tz1.gif');
            return message.channel.send({ embeds: [embed] });
        }
        
        domainsData.domains.push({ domain: newDomain, thumbnail, image, addedBy: message.author.id, addedAt: new Date().toISOString() });
        saveDomains(domainsData);
        
        await logCommand(client, message.guild, message.author, '+domains_setup', `Domain: ${newDomain}`);
        
        const embed = new EmbedBuilder()
            .setColor('#a000c8')
            .setTitle('<a:novaflare_check:1446514493210497045> Domain Added')
            .setDescription(`Successfully added domain: \`${newDomain}\``)
            .addFields(
                { name: 'Thumbnail', value: thumbnail || 'Not set', inline: true },
                { name: 'Image', value: image || 'Not set', inline: true }
            )
            .setFooter({ text: `Added by ${message.author.username}` })
            .setTimestamp();
        return message.channel.send({ embeds: [embed] });
    }

    // +domain_edit command
    if (commandName === 'domain_edit') {
        if (!message.member.permissions.has('Administrator')) {
            const embed = new EmbedBuilder()
                .setColor('#a000c8')
                .setTitle('**❌ Permission Denied**')
                .setDescription('Only administrators can use this command.')
                .setImage('https://cdn.discordapp.com/attachments/1442093639822999572/1446770767906996359/purple-anime-498-x-275-gif-aqa2h5dv1g168tz1.gif');
            return message.channel.send({ embeds: [embed] });
        }
        
        const args = message.content.slice('+domain_edit'.length + 1).trim().split('|').map(s => s.trim());
        if (args.length < 2 || !args[0]) {
            const embed = new EmbedBuilder()
                .setColor('#a000c8')
                .setTitle('**❌ Invalid Usage**')
                .setDescription('Usage: `+domain_edit <domain> | <thumbnail_url> | <image_url>`\nLeave empty to keep current value.')
                .setImage('https://cdn.discordapp.com/attachments/1442093639822999572/1446770767906996359/purple-anime-498-x-275-gif-aqa2h5dv1g168tz1.gif');
            return message.channel.send({ embeds: [embed] });
        }
        
        const domainsData = loadDomains();
        const domainIndex = domainsData.domains.findIndex(d => d.domain === args[0]);
        
        if (domainIndex === -1) {
            const embed = new EmbedBuilder()
                .setColor('#a000c8')
                .setTitle('**❌ Domain Not Found**')
                .setDescription(`The domain \`${args[0]}\` does not exist.`)
                .setImage('https://cdn.discordapp.com/attachments/1442093639822999572/1446770767906996359/purple-anime-498-x-275-gif-aqa2h5dv1g168tz1.gif');
            return message.channel.send({ embeds: [embed] });
        }
        
        if (args[1]) domainsData.domains[domainIndex].thumbnail = args[1];
        if (args[2]) domainsData.domains[domainIndex].image = args[2];
        saveDomains(domainsData);
        
        await logCommand(client, message.guild, message.author, '+domain_edit', `Domain: ${args[0]}`);
        
        const embed = new EmbedBuilder()
            .setColor('#a000c8')
            .setTitle('<a:novaflare_check:1446514493210497045> Domain Updated')
            .setDescription(`Successfully updated domain: \`${args[0]}\``)
            .setFooter({ text: `Edited by ${message.author.username}` })
            .setTimestamp();
        return message.channel.send({ embeds: [embed] });
    }

    // +domain_delete command
    if (commandName === 'domain_delete') {
        if (!message.member.permissions.has('Administrator')) {
            const embed = new EmbedBuilder()
                .setColor('#a000c8')
                .setTitle('**❌ Permission Denied**')
                .setDescription('Only administrators can use this command.')
                .setImage('https://cdn.discordapp.com/attachments/1442093639822999572/1446770767906996359/purple-anime-498-x-275-gif-aqa2h5dv1g168tz1.gif');
            return message.channel.send({ embeds: [embed] });
        }
        
        const domain = message.content.slice('+domain_delete'.length + 1).trim();
        if (!domain) {
            const embed = new EmbedBuilder()
                .setColor('#a000c8')
                .setTitle('**❌ Invalid Usage**')
                .setDescription('Usage: `+domain_delete <domain>`')
                .setImage('https://cdn.discordapp.com/attachments/1442093639822999572/1446770767906996359/purple-anime-498-x-275-gif-aqa2h5dv1g168tz1.gif');
            return message.channel.send({ embeds: [embed] });
        }
        
        const domainsData = loadDomains();
        const domainIndex = domainsData.domains.findIndex(d => d.domain === domain);
        
        if (domainIndex === -1) {
            const embed = new EmbedBuilder()
                .setColor('#a000c8')
                .setTitle('**❌ Domain Not Found**')
                .setDescription(`The domain \`${domain}\` does not exist.`)
                .setImage('https://cdn.discordapp.com/attachments/1442093639822999572/1446770767906996359/purple-anime-498-x-275-gif-aqa2h5dv1g168tz1.gif');
            return message.channel.send({ embeds: [embed] });
        }
        
        domainsData.domains.splice(domainIndex, 1);
        saveDomains(domainsData);
        
        await logCommand(client, message.guild, message.author, '+domain_delete', `Domain: ${domain}`);
        
        const embed = new EmbedBuilder()
            .setColor('#a000c8')
            .setTitle('<a:novaflare_check:1446514493210497045> Domain Deleted')
            .setDescription(`Successfully deleted domain: \`${domain}\``)
            .setFooter({ text: `Deleted by ${message.author.username}` })
            .setTimestamp();
        return message.channel.send({ embeds: [embed] });
    }

    // +domains command - show all domains with HTTP status
    if (commandName === 'domains') {
        const domainsData = loadDomains();
        
        if (domainsData.domains.length === 0) {
            const embed = new EmbedBuilder()
                .setColor('#a000c8')
                .setTitle('**📋 Domains**')
                .setDescription('No domains configured yet. Use `+domains_setup` to add one.')
                .setImage('https://cdn.discordapp.com/attachments/1442093639822999572/1446770767906996359/purple-anime-498-x-275-gif-aqa2h5dv1g168tz1.gif');
            return message.channel.send({ embeds: [embed] });
        }
        
        const statusChecks = await Promise.all(domainsData.domains.map(async (d) => {
            try {
                const url = d.domain.startsWith('http') ? d.domain : `https://${d.domain}`;
                const response = await fetch(url, { method: 'HEAD', signal: AbortSignal.timeout(5000) });
                return { domain: d.domain, status: response.ok ? '🟢 Online' : '🟡 Issues', code: response.status };
            } catch (e) {
                return { domain: d.domain, status: '🔴 Offline', code: 'N/A' };
            }
        }));
        
        const domainList = statusChecks.map((s, i) => 
            `**${i + 1}.** \`${s.domain}\` - ${s.status} (${s.code})`
        ).join('\n');
        
        const embed = new EmbedBuilder()
            .setColor('#a000c8')
            .setTitle('<a:novaflare_star:1446514209411043328> Configured Domains')
            .setDescription(domainList)
            .setFooter({ text: `Total: ${domainsData.domains.length} domains` })
            .setTimestamp();
        return message.channel.send({ embeds: [embed] });
    }

    // +kick command
    if (commandName === 'kick') {
        if (!isStaffOrAdmin(message.member)) {
            const embed = new EmbedBuilder()
                .setColor('#a000c8')
                .setTitle('**❌ Permission Denied**')
                .setDescription('You do not have permission to use this command.')
                .setImage('https://cdn.discordapp.com/attachments/1442093639822999572/1446770767906996359/purple-anime-498-x-275-gif-aqa2h5dv1g168tz1.gif');
            return message.channel.send({ embeds: [embed] });
        }
        
        const args = message.content.slice('+kick'.length + 1).trim().split(' ');
        const target = getUserFromMentionOrId(message, args[0]);
        const reason = args.slice(1).join(' ') || 'No reason provided';
        
        if (!target) {
            const embed = new EmbedBuilder()
                .setColor('#a000c8')
                .setTitle('**❌ Invalid Usage**')
                .setDescription('Usage: `+kick @user [reason]`')
                .setImage('https://cdn.discordapp.com/attachments/1442093639822999572/1446770767906996359/purple-anime-498-x-275-gif-aqa2h5dv1g168tz1.gif');
            return message.channel.send({ embeds: [embed] });
        }
        
        if (!target.kickable) {
            const embed = new EmbedBuilder()
                .setColor('#a000c8')
                .setTitle('**❌ Cannot Kick**')
                .setDescription('I cannot kick this user. They may have higher permissions.')
                .setImage('https://cdn.discordapp.com/attachments/1442093639822999572/1446770767906996359/purple-anime-498-x-275-gif-aqa2h5dv1g168tz1.gif');
            return message.channel.send({ embeds: [embed] });
        }
        
        try {
            await target.kick(reason);
            await logCommand(client, message.guild, message.author, '+kick', `Target: ${target.user.tag}\nReason: ${reason}`);
            
            const embed = new EmbedBuilder()
                .setColor('#a000c8')
                .setTitle('<a:novaflare_check:1446514493210497045> User Kicked')
                .setDescription(`**${target.user.tag}** has been kicked.`)
                .addFields({ name: 'Reason', value: reason })
                .setFooter({ text: `Kicked by ${message.author.username}` })
                .setTimestamp();
            return message.channel.send({ embeds: [embed] });
        } catch (e) {
            console.error('Kick error:', e);
            return message.channel.send({ content: 'Failed to kick user.' });
        }
    }

    // +ban command
    if (commandName === 'ban') {
        if (!isStaffOrAdmin(message.member)) {
            const embed = new EmbedBuilder()
                .setColor('#a000c8')
                .setTitle('**❌ Permission Denied**')
                .setDescription('You do not have permission to use this command.')
                .setImage('https://cdn.discordapp.com/attachments/1442093639822999572/1446770767906996359/purple-anime-498-x-275-gif-aqa2h5dv1g168tz1.gif');
            return message.channel.send({ embeds: [embed] });
        }
        
        const args = message.content.slice('+ban'.length + 1).trim().split(' ');
        const target = getUserFromMentionOrId(message, args[0]);
        const reason = args.slice(1).join(' ') || 'No reason provided';
        
        if (!target) {
            const embed = new EmbedBuilder()
                .setColor('#a000c8')
                .setTitle('**❌ Invalid Usage**')
                .setDescription('Usage: `+ban @user [reason]`')
                .setImage('https://cdn.discordapp.com/attachments/1442093639822999572/1446770767906996359/purple-anime-498-x-275-gif-aqa2h5dv1g168tz1.gif');
            return message.channel.send({ embeds: [embed] });
        }
        
        if (!target.bannable) {
            const embed = new EmbedBuilder()
                .setColor('#a000c8')
                .setTitle('**❌ Cannot Ban**')
                .setDescription('I cannot ban this user. They may have higher permissions.')
                .setImage('https://cdn.discordapp.com/attachments/1442093639822999572/1446770767906996359/purple-anime-498-x-275-gif-aqa2h5dv1g168tz1.gif');
            return message.channel.send({ embeds: [embed] });
        }
        
        try {
            await target.ban({ reason });
            
            // Track ban
            const bansData = loadBans();
            bansData.bans.push({
                oderId: target.user.id,
                odertag: target.user.tag,
                reason,
                bannedBy: message.author.id,
                bannedAt: new Date().toISOString()
            });
            saveBans(bansData);
            
            await logCommand(client, message.guild, message.author, '+ban', `Target: ${target.user.tag}\nReason: ${reason}`);
            
            const embed = new EmbedBuilder()
                .setColor('#a000c8')
                .setTitle('<a:novaflare_check:1446514493210497045> User Banned')
                .setDescription(`**${target.user.tag}** has been banned.`)
                .addFields({ name: 'Reason', value: reason })
                .setFooter({ text: `Banned by ${message.author.username}` })
                .setTimestamp();
            return message.channel.send({ embeds: [embed] });
        } catch (e) {
            console.error('Ban error:', e);
            return message.channel.send({ content: 'Failed to ban user.' });
        }
    }

    // +unban command
    if (commandName === 'unban') {
        if (!isStaffOrAdmin(message.member)) {
            const embed = new EmbedBuilder()
                .setColor('#a000c8')
                .setTitle('**❌ Permission Denied**')
                .setDescription('You do not have permission to use this command.')
                .setImage('https://cdn.discordapp.com/attachments/1442093639822999572/1446770767906996359/purple-anime-498-x-275-gif-aqa2h5dv1g168tz1.gif');
            return message.channel.send({ embeds: [embed] });
        }
        
        const userId = message.content.slice('+unban'.length + 1).trim();
        if (!userId || !/^\d+$/.test(userId)) {
            const embed = new EmbedBuilder()
                .setColor('#a000c8')
                .setTitle('**❌ Invalid Usage**')
                .setDescription('Usage: `+unban <user_id>`')
                .setImage('https://cdn.discordapp.com/attachments/1442093639822999572/1446770767906996359/purple-anime-498-x-275-gif-aqa2h5dv1g168tz1.gif');
            return message.channel.send({ embeds: [embed] });
        }
        
        try {
            await message.guild.members.unban(userId);
            
            // Remove from tracked bans
            const bansData = loadBans();
            bansData.bans = bansData.bans.filter(b => b.userId !== userId);
            saveBans(bansData);
            
            await logCommand(client, message.guild, message.author, '+unban', `User ID: ${userId}`);
            
            const embed = new EmbedBuilder()
                .setColor('#a000c8')
                .setTitle('<a:novaflare_check:1446514493210497045> User Unbanned')
                .setDescription(`User ID \`${userId}\` has been unbanned.`)
                .setFooter({ text: `Unbanned by ${message.author.username}` })
                .setTimestamp();
            return message.channel.send({ embeds: [embed] });
        } catch (e) {
            console.error('Unban error:', e);
            const embed = new EmbedBuilder()
                .setColor('#a000c8')
                .setTitle('**❌ Unban Failed**')
                .setDescription('Could not unban this user. They may not be banned.')
                .setImage('https://cdn.discordapp.com/attachments/1442093639822999572/1446770767906996359/purple-anime-498-x-275-gif-aqa2h5dv1g168tz1.gif');
            return message.channel.send({ embeds: [embed] });
        }
    }

    // +banned_list command
    if (commandName === 'banned_list') {
        if (!isStaffOrAdmin(message.member)) {
            const embed = new EmbedBuilder()
                .setColor('#a000c8')
                .setTitle('**❌ Permission Denied**')
                .setDescription('You do not have permission to use this command.')
                .setImage('https://cdn.discordapp.com/attachments/1442093639822999572/1446770767906996359/purple-anime-498-x-275-gif-aqa2h5dv1g168tz1.gif');
            return message.channel.send({ embeds: [embed] });
        }
        
        try {
            const bans = await message.guild.bans.fetch();
            
            if (bans.size === 0) {
                const embed = new EmbedBuilder()
                    .setColor('#a000c8')
                    .setTitle('**📋 Banned Users**')
                    .setDescription('No users are currently banned.');
                return message.channel.send({ embeds: [embed] });
            }
            
            const banList = bans.map((ban, i) => 
                `**${ban.user.tag}** (\`${ban.user.id}\`)\nReason: ${ban.reason || 'No reason'}`
            ).slice(0, 10).join('\n\n');
            
            const embed = new EmbedBuilder()
                .setColor('#a000c8')
                .setTitle('<a:novaflare_star:1446514209411043328> Banned Users')
                .setDescription(banList)
                .setFooter({ text: `Total: ${bans.size} banned users (showing up to 10)` })
                .setTimestamp();
            return message.channel.send({ embeds: [embed] });
        } catch (e) {
            console.error('Banned list error:', e);
            return message.channel.send({ content: 'Failed to fetch ban list.' });
        }
    }

    // +timeout command
    if (commandName === 'timeout') {
        if (!isStaffOrAdmin(message.member)) {
            const embed = new EmbedBuilder()
                .setColor('#a000c8')
                .setTitle('**❌ Permission Denied**')
                .setDescription('You do not have permission to use this command.')
                .setImage('https://cdn.discordapp.com/attachments/1442093639822999572/1446770767906996359/purple-anime-498-x-275-gif-aqa2h5dv1g168tz1.gif');
            return message.channel.send({ embeds: [embed] });
        }
        
        const args = message.content.slice('+timeout'.length + 1).trim().split(' ');
        const target = getUserFromMentionOrId(message, args[0]);
        const duration = args[1] ? parseTimeString(args[1]) : null;
        const reason = args.slice(2).join(' ') || 'No reason provided';
        
        if (!target || !duration) {
            const embed = new EmbedBuilder()
                .setColor('#a000c8')
                .setTitle('**❌ Invalid Usage**')
                .setDescription('Usage: `+timeout @user <duration> [reason]`\nDuration examples: 1m, 1h, 1d, 1w')
                .setImage('https://cdn.discordapp.com/attachments/1442093639822999572/1446770767906996359/purple-anime-498-x-275-gif-aqa2h5dv1g168tz1.gif');
            return message.channel.send({ embeds: [embed] });
        }
        
        if (!target.moderatable) {
            const embed = new EmbedBuilder()
                .setColor('#a000c8')
                .setTitle('**❌ Cannot Timeout**')
                .setDescription('I cannot timeout this user. They may have higher permissions.')
                .setImage('https://cdn.discordapp.com/attachments/1442093639822999572/1446770767906996359/purple-anime-498-x-275-gif-aqa2h5dv1g168tz1.gif');
            return message.channel.send({ embeds: [embed] });
        }
        
        try {
            await target.timeout(duration, reason);
            await logCommand(client, message.guild, message.author, '+timeout', `Target: ${target.user.tag}\nDuration: ${args[1]}\nReason: ${reason}`);
            
            const embed = new EmbedBuilder()
                .setColor('#a000c8')
                .setTitle('<a:novaflare_check:1446514493210497045> User Timed Out')
                .setDescription(`**${target.user.tag}** has been timed out for ${args[1]}.`)
                .addFields({ name: 'Reason', value: reason })
                .setFooter({ text: `Timed out by ${message.author.username}` })
                .setTimestamp();
            return message.channel.send({ embeds: [embed] });
        } catch (e) {
            console.error('Timeout error:', e);
            return message.channel.send({ content: 'Failed to timeout user.' });
        }
    }

    // +untimeout command
    if (commandName === 'untimeout') {
        if (!isStaffOrAdmin(message.member)) {
            const embed = new EmbedBuilder()
                .setColor('#a000c8')
                .setTitle('**❌ Permission Denied**')
                .setDescription('You do not have permission to use this command.')
                .setImage('https://cdn.discordapp.com/attachments/1442093639822999572/1446770767906996359/purple-anime-498-x-275-gif-aqa2h5dv1g168tz1.gif');
            return message.channel.send({ embeds: [embed] });
        }
        
        const args = message.content.slice('+untimeout'.length + 1).trim().split(' ');
        const target = getUserFromMentionOrId(message, args[0]);
        
        if (!target) {
            const embed = new EmbedBuilder()
                .setColor('#a000c8')
                .setTitle('**❌ Invalid Usage**')
                .setDescription('Usage: `+untimeout @user`')
                .setImage('https://cdn.discordapp.com/attachments/1442093639822999572/1446770767906996359/purple-anime-498-x-275-gif-aqa2h5dv1g168tz1.gif');
            return message.channel.send({ embeds: [embed] });
        }
        
        try {
            await target.timeout(null);
            await logCommand(client, message.guild, message.author, '+untimeout', `Target: ${target.user.tag}`);
            
            const embed = new EmbedBuilder()
                .setColor('#a000c8')
                .setTitle('<a:novaflare_check:1446514493210497045> Timeout Removed')
                .setDescription(`**${target.user.tag}**'s timeout has been removed.`)
                .setFooter({ text: `Removed by ${message.author.username}` })
                .setTimestamp();
            return message.channel.send({ embeds: [embed] });
        } catch (e) {
            console.error('Untimeout error:', e);
            return message.channel.send({ content: 'Failed to remove timeout.' });
        }
    }

    // +purge command (admin only)
    if (commandName === 'purge') {
        if (!message.member.permissions.has('Administrator')) {
            const embed = new EmbedBuilder()
                .setColor('#a000c8')
                .setTitle('**❌ Permission Denied**')
                .setDescription('Only administrators can use this command.')
                .setImage('https://cdn.discordapp.com/attachments/1442093639822999572/1446770767906996359/purple-anime-498-x-275-gif-aqa2h5dv1g168tz1.gif');
            return message.channel.send({ embeds: [embed] });
        }
        
        const amount = parseInt(message.content.slice('+purge'.length + 1).trim());
        if (isNaN(amount) || amount < 1 || amount > 100) {
            const embed = new EmbedBuilder()
                .setColor('#a000c8')
                .setTitle('**❌ Invalid Usage**')
                .setDescription('Usage: `+purge <1-100>`')
                .setImage('https://cdn.discordapp.com/attachments/1442093639822999572/1446770767906996359/purple-anime-498-x-275-gif-aqa2h5dv1g168tz1.gif');
            return message.channel.send({ embeds: [embed] });
        }
        
        try {
            await message.delete();
            const deleted = await message.channel.bulkDelete(amount, true);
            await logCommand(client, message.guild, message.author, '+purge', `Channel: ${message.channel.name}\nMessages: ${deleted.size}`);
            
            const embed = new EmbedBuilder()
                .setColor('#a000c8')
                .setTitle('<a:novaflare_check:1446514493210497045> Messages Purged')
                .setDescription(`Successfully deleted **${deleted.size}** messages.`)
                .setFooter({ text: `Purged by ${message.author.username}` })
                .setTimestamp();
            const reply = await message.channel.send({ embeds: [embed] });
            setTimeout(() => reply.delete().catch(() => {}), 5000);
        } catch (e) {
            console.error('Purge error:', e);
            return message.channel.send({ content: 'Failed to purge messages.' });
        }
        return;
    }

    // +welcome_setup command
    if (commandName === 'welcome_setup') {
        if (!message.member.permissions.has('Administrator')) {
            const embed = new EmbedBuilder()
                .setColor('#a000c8')
                .setTitle('**❌ Permission Denied**')
                .setDescription('Only administrators can use this command.')
                .setImage('https://cdn.discordapp.com/attachments/1442093639822999572/1446770767906996359/purple-anime-498-x-275-gif-aqa2h5dv1g168tz1.gif');
            return message.channel.send({ embeds: [embed] });
        }
        
        const channel = message.mentions.channels.first();
        if (!channel) {
            const embed = new EmbedBuilder()
                .setColor('#a000c8')
                .setTitle('**❌ Invalid Usage**')
                .setDescription('Usage: `+welcome_setup #channel`')
                .setImage('https://cdn.discordapp.com/attachments/1442093639822999572/1446770767906996359/purple-anime-498-x-275-gif-aqa2h5dv1g168tz1.gif');
            return message.channel.send({ embeds: [embed] });
        }
        
        const welcomeData = loadWelcome();
        welcomeData.enabled = true;
        welcomeData.channelId = channel.id;
        saveWelcome(welcomeData);
        
        await logCommand(client, message.guild, message.author, '+welcome_setup', `Channel: ${channel.name}`);
        
        const embed = new EmbedBuilder()
            .setColor('#a000c8')
            .setTitle('<a:novaflare_check:1446514493210497045> Welcome Channel Set')
            .setDescription(`Welcome messages will now be sent to ${channel}.\nUse \`+welcome_edit\` to customize the message.`)
            .setFooter({ text: `Set by ${message.author.username}` })
            .setTimestamp();
        return message.channel.send({ embeds: [embed] });
    }

    // +welcome_edit command
    if (commandName === 'welcome_edit') {
        if (!message.member.permissions.has('Administrator')) {
            const embed = new EmbedBuilder()
                .setColor('#a000c8')
                .setTitle('**❌ Permission Denied**')
                .setDescription('Only administrators can use this command.')
                .setImage('https://cdn.discordapp.com/attachments/1442093639822999572/1446770767906996359/purple-anime-498-x-275-gif-aqa2h5dv1g168tz1.gif');
            return message.channel.send({ embeds: [embed] });
        }
        
        const args = message.content.slice('+welcome_edit'.length + 1).trim().split('|').map(s => s.trim());
        if (args.length < 2 || !args[0]) {
            const embed = new EmbedBuilder()
                .setColor('#a000c8')
                .setTitle('**❌ Invalid Usage**')
                .setDescription('Usage: `+welcome_edit <title> | <description>`\nVariables: {user}, {server}, {memberCount}')
                .setImage('https://cdn.discordapp.com/attachments/1442093639822999572/1446770767906996359/purple-anime-498-x-275-gif-aqa2h5dv1g168tz1.gif');
            return message.channel.send({ embeds: [embed] });
        }
        
        const welcomeData = loadWelcome();
        welcomeData.title = args[0];
        welcomeData.description = args[1];
        saveWelcome(welcomeData);
        
        await logCommand(client, message.guild, message.author, '+welcome_edit', `Title: ${args[0]}`);
        
        const embed = new EmbedBuilder()
            .setColor('#a000c8')
            .setTitle('<a:novaflare_check:1446514493210497045> Welcome Message Updated')
            .setDescription('The welcome message has been updated.')
            .addFields(
                { name: 'Title', value: args[0] },
                { name: 'Description', value: args[1] }
            )
            .setFooter({ text: `Edited by ${message.author.username}` })
            .setTimestamp();
        return message.channel.send({ embeds: [embed] });
    }

    // +logs command
    if (commandName === 'logs') {
        if (!message.member.permissions.has('Administrator')) {
            const embed = new EmbedBuilder()
                .setColor('#a000c8')
                .setTitle('**❌ Permission Denied**')
                .setDescription('Only administrators can use this command.')
                .setImage('https://cdn.discordapp.com/attachments/1442093639822999572/1446770767906996359/purple-anime-498-x-275-gif-aqa2h5dv1g168tz1.gif');
            return message.channel.send({ embeds: [embed] });
        }
        
        const channel = message.mentions.channels.first();
        if (!channel) {
            const embed = new EmbedBuilder()
                .setColor('#a000c8')
                .setTitle('**❌ Invalid Usage**')
                .setDescription('Usage: `+logs #channel`')
                .setImage('https://cdn.discordapp.com/attachments/1442093639822999572/1446770767906996359/purple-anime-498-x-275-gif-aqa2h5dv1g168tz1.gif');
            return message.channel.send({ embeds: [embed] });
        }
        
        const logsData = loadLogs();
        logsData.channelId = channel.id;
        saveLogs(logsData);
        
        const embed = new EmbedBuilder()
            .setColor('#a000c8')
            .setTitle('<a:novaflare_check:1446514493210497045> Logs Channel Set')
            .setDescription(`Command logs will now be sent to ${channel}.`)
            .setFooter({ text: `Set by ${message.author.username}` })
            .setTimestamp();
        return message.channel.send({ embeds: [embed] });
    }

    const msgData = messages[commandName];
    if (!msgData) return;

    const embed = new EmbedBuilder();
    if (msgData.color) embed.setColor(msgData.color);
    if (msgData.title) embed.setTitle(msgData.title);
    if (msgData.description) embed.setDescription(msgData.description);
    if (msgData.image) embed.setImage(msgData.image);
    if (msgData.thumbnail) embed.setThumbnail(msgData.thumbnail);
    if (msgData.footer) embed.setFooter({ text: msgData.footer });

    const components = [];
    if (msgData.buttons && msgData.buttons.length > 0) {
        const row = new ActionRowBuilder();
        for (const btn of msgData.buttons) {
            if (btn.type === 'link') {
                const button = new ButtonBuilder()
                    .setLabel(btn.label)
                    .setStyle(ButtonStyle.Link)
                    .setURL(btn.url);
                if (btn.emoji) button.setEmoji(btn.emoji);
                row.addComponents(button);
            } else {
                const button = new ButtonBuilder()
                    .setCustomId(btn.id)
                    .setLabel(btn.label)
                    .setStyle(getButtonStyleFromColor(btn.color));
                if (btn.emoji) button.setEmoji(btn.emoji);
                row.addComponents(button);
            }
        }
        components.push(row);
    }

    try {
        await message.channel.send({ embeds: [embed], components });
    } catch (error) {
        console.error('Error sending custom message:', error);
    }
});

// Helper function to get button style from color name
function getButtonStyleFromColor(color) {
    switch(color?.toLowerCase()) {
        case 'grey': return ButtonStyle.Secondary;
        case 'green': return ButtonStyle.Success;
        case 'red': return ButtonStyle.Danger;
        case 'blue': return ButtonStyle.Primary;
        default: return ButtonStyle.Primary;
    }
}

// Login to Discord
client.login(process.env.DISCORD_TOKEN);