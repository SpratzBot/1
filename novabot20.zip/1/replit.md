# Novaflare Discord Bot

## Overview
A Discord moderation bot built with discord.js v14. The bot provides various moderation features including blacklist management, auto-purge, welcome messages, logging, and more.

## Project Structure
```
├── index.js              # Main bot entry point
├── deploy-commands.js    # Script to deploy slash commands
├── config.json           # Bot configuration
├── commands/
│   ├── messageCommands.js
│   ├── moderationCommands.js
│   └── slashCommands.js
├── data/                 # JSON data storage
│   ├── autopurge.json
│   ├── bans.json
│   ├── blacklist.json
│   ├── domains.json
│   ├── logs.json
│   ├── messages.json
│   ├── roles.json
│   ├── staff.json
│   └── welcome.json
└── package.json
```

## Environment Variables
Required secrets (configured in Replit Secrets):
- `DISCORD_TOKEN` - Discord bot token from Developer Portal
- `CLIENT_ID` - Bot's Client ID (optional, in .env)
- `GUILD_ID` - Discord server ID for testing (optional, in .env)
- `ALLOWED_ROLES` - Comma-separated role IDs (optional, in .env)
- `BOT_COLOR` - Bot embed color theme (optional, in .env)

## Running the Bot
The bot runs automatically via the "Discord Bot" workflow which executes `node index.js`.

## Deployment
Configured for VM deployment (always-on) since Discord bots need to maintain persistent connections.

## Features
- Blacklist word filtering with bypass options
- Auto-purge channels on schedule
- Welcome messages for new members
- Command logging
- Staff role management
- Ban management
- Domain filtering
