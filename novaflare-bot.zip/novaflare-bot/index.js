require('dotenv').config();
const { Client, GatewayIntentBits, Collection, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');
const fs = require('fs');
const path = require('path');

// Blacklist and autopurge paths
const blacklistPath = path.join(__dirname, 'data', 'blacklist.json');
const autopurgePath = path.join(__dirname, 'data', 'autopurge.json');

// Auto-purge intervals storage
const autopurgeIntervals = new Map();

function loadBlacklist() {
    if (!fs.existsSync(blacklistPath)) {
        fs.writeFileSync(blacklistPath, JSON.stringify({ words: [], bypassUsers: [], bypassRoles: [], bypassChannels: [] }));
    }
    return JSON.parse(fs.readFileSync(blacklistPath, 'utf8'));
}

function loadAutopurge() {
    if (!fs.existsSync(autopurgePath)) {
        fs.writeFileSync(autopurgePath, JSON.stringify({}));
    }
    return JSON.parse(fs.readFileSync(autopurgePath, 'utf8'));
}

// URL detection regex
const urlRegex = /(https?:\/\/[^\s]+)|(www\.[^\s]+)|([a-zA-Z0-9][-a-zA-Z0-9]*\.(com|org|net|io|gg|xyz|co|me|tv|info|biz|app|dev)[^\s]*)/gi;

// Create client instance
const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMembers
    ]
});

// Load configuration
const config = require('./config.json');

// Load data
const messagesPath = path.join(__dirname, 'data', 'messages.json');
const rolesPath = path.join(__dirname, 'data', 'roles.json');

// Ensure data directory exists
if (!fs.existsSync(path.join(__dirname, 'data'))) {
    fs.mkdirSync(path.join(__dirname, 'data'));
}

// Initialize data files if they don't exist
if (!fs.existsSync(messagesPath)) {
    fs.writeFileSync(messagesPath, JSON.stringify({}));
}
if (!fs.existsSync(rolesPath)) {
    fs.writeFileSync(rolesPath, JSON.stringify({ allowedRoles: [] }));
}

// Load messages and roles
let messages = JSON.parse(fs.readFileSync(messagesPath, 'utf8'));
let allowedRoles = JSON.parse(fs.readFileSync(rolesPath, 'utf8')).allowedRoles || [];

// Store active user sessions
const userSessions = new Map();

// Message creation wizard steps
const WIZARD_STEPS = {
    COLOR: 'color',
    TITLE: 'title',
    DESCRIPTION: 'description',
    IMAGES: 'images',
    FOOTER: 'footer',
    REPEAT: 'repeat',
    BUTTONS: 'buttons',
    COMMAND_NAME: 'command_name'
};

// Helper function to save data
function saveData() {
    fs.writeFileSync(messagesPath, JSON.stringify(messages, null, 2));
    fs.writeFileSync(rolesPath, JSON.stringify({ allowedRoles }, null, 2));
}

// Check if user has permission
function hasPermission(member) {
    if (member.permissions.has('Administrator')) return true;
    return member.roles.cache.some(role => allowedRoles.includes(role.id));
}

// Load commands
client.commands = new Collection();
const commandFiles = fs.readdirSync(path.join(__dirname, 'commands')).filter(file => file.endsWith('.js'));

for (const file of commandFiles) {
    const command = require(path.join(__dirname, 'commands', file));
    if (Array.isArray(command)) {
        for (const cmd of command) {
            client.commands.set(cmd.data.name, cmd);
        }
    } else {
        client.commands.set(command.data.name, command);
    }
}

// Auto-purge function
async function performAutoPurge(channelId, guildId) {
    try {
        const guild = client.guilds.cache.get(guildId);
        if (!guild) return;
        
        const channel = guild.channels.cache.get(channelId);
        if (!channel) return;

        const startTime = Date.now();
        
        let deleted = 0;
        let fetched;
        do {
            fetched = await channel.messages.fetch({ limit: 100 });
            const deletable = fetched.filter(msg => Date.now() - msg.createdTimestamp < 14 * 24 * 60 * 60 * 1000);
            if (deletable.size > 0) {
                await channel.bulkDelete(deletable, true);
                deleted += deletable.size;
            }
        } while (fetched.size >= 100);

        const endTime = Date.now();
        const timeTaken = ((endTime - startTime) / 1000).toFixed(2);

        const embed = new EmbedBuilder()
            .setColor('#000001')
            .setTitle('**Auto-Purge Result**')
            .setDescription(`Purge successfully\nTime taken: **${timeTaken}s**\nMessages deleted: **${deleted}**`)
            .setImage('https://cdn.discordapp.com/attachments/1442093639822999572/1442154889722597386/844f7e76c6e1eeb8266be6b17362b385.gif');

        await channel.send({ embeds: [embed] });
    } catch (error) {
        console.error('Auto-purge error:', error);
    }
}

// Start auto-purge intervals
function startAutoPurgeIntervals() {
    const autopurge = loadAutopurge();
    
    for (const [channelId, config] of Object.entries(autopurge)) {
        if (autopurgeIntervals.has(channelId)) {
            clearInterval(autopurgeIntervals.get(channelId));
        }
        
        const interval = setInterval(() => {
            performAutoPurge(channelId, config.guildId);
        }, config.interval);
        
        autopurgeIntervals.set(channelId, interval);
        console.log(`📋 Auto-purge scheduled for channel ${channelId} every ${config.timeString}`);
    }
}

// Clear a specific auto-purge interval
function clearAutoPurgeInterval(channelId) {
    if (autopurgeIntervals.has(channelId)) {
        clearInterval(autopurgeIntervals.get(channelId));
        autopurgeIntervals.delete(channelId);
        console.log(`📋 Auto-purge removed for channel ${channelId}`);
    }
}

// Bot ready event
client.once('ready', () => {
    console.log(`✅ Logged in as ${client.user.tag}!`);
    console.log(`📊 ${Object.keys(messages).length} messages loaded`);
    startAutoPurgeIntervals();
});

// Interaction handling
client.on('interactionCreate', async interaction => {
    // Handle slash commands
    if (interaction.isChatInputCommand()) {
        const command = client.commands.get(interaction.commandName);

        if (!command) return;

        try {
            // Check permissions for message commands
            if (interaction.commandName.startsWith('message')) {
                if (!hasPermission(interaction.member)) {
                    return interaction.reply({ 
                        content: '❌ You do not have permission to use this command.', 
                        ephemeral: true 
                    });
                }
            }

            await command.execute(interaction, { 
                messages, 
                allowedRoles, 
                saveData, 
                userSessions,
                config,
                WIZARD_STEPS,
                startAutoPurgeIntervals,
                clearAutoPurgeInterval
            });
        } catch (error) {
            console.error(error);
            try {
                if (interaction.replied || interaction.deferred) {
                    await interaction.followUp({ 
                        content: 'There was an error executing this command!', 
                        ephemeral: true 
                    });
                } else {
                    await interaction.reply({ 
                        content: 'There was an error executing this command!', 
                        ephemeral: true 
                    });
                }
            } catch (e) {
                console.error('Failed to send error message:', e);
            }
        }
    }

    // Handle buttons
    else if (interaction.isButton()) {
        await handleButton(interaction);
    }

    // Handle modal submissions
    else if (interaction.isModalSubmit()) {
        await handleModal(interaction);
    }
});

// Button handler
async function handleButton(interaction) {
    const [action, userId, step] = interaction.customId.split('_');

    if (userId !== interaction.user.id) {
        return interaction.reply({ 
            content: 'This interaction is not for you!', 
            ephemeral: true 
        });
    }

    const session = userSessions.get(userId);
    if (!session) {
        return interaction.reply({ 
            content: 'Your session has expired. Please start over.', 
            ephemeral: true 
        });
    }

    switch(action) {
        case 'color':
        case 'title':
        case 'description':
        case 'footer':
        case 'repeat':
            await showModalForStep(interaction, step || action);
            break;
        case 'image':
        case 'thumbnail':
        case 'skip':
        case 'addbutton':
        case 'addlink':
        case 'submit':
            await handleWizardAction(interaction, action, session);
            break;
    }
}

// Modal handler
async function handleModal(interaction) {
    const [action, userId] = interaction.customId.split('_');

    const session = userSessions.get(userId);
    if (!session) {
        return interaction.reply({ 
            content: 'Your session has expired. Please start over.', 
            ephemeral: true 
        });
    }

    switch(action) {
        case 'color':
            session.color = interaction.fields.getTextInputValue('color');
            await showTitleStep(interaction, session);
            break;
        case 'title':
            session.title = interaction.fields.getTextInputValue('title');
            await showDescriptionStep(interaction, session);
            break;
        case 'description':
            session.description = interaction.fields.getTextInputValue('description');
            await showImagesStep(interaction, session);
            break;
        case 'footer':
            session.footer = interaction.fields.getTextInputValue('footer');
            await showRepeatStep(interaction, session);
            break;
        case 'repeat':
            session.repeat = parseInt(interaction.fields.getTextInputValue('repeat'));
            await showButtonsStep(interaction, session);
            break;
        case 'button':
            const buttonName = interaction.fields.getTextInputValue('buttonName');
            const emoji = interaction.fields.getTextInputValue('emoji');
            const buttonDescription = interaction.fields.getTextInputValue('description');
            const color = interaction.fields.getTextInputValue('color');

            session.buttons = session.buttons || [];
            session.buttons.push({
                type: 'action',
                label: buttonName,
                emoji: emoji || null,
                description: buttonDescription,
                color: color,
                id: `btn_${session.buttons.length + 1}`
            });

            await showButtonsStep(interaction, session);
            break;
        case 'link':
            const linkName = interaction.fields.getTextInputValue('buttonName');
            const linkEmoji = interaction.fields.getTextInputValue('emoji');
            const url = interaction.fields.getTextInputValue('url');

            session.buttons = session.buttons || [];
            session.buttons.push({
                type: 'link',
                label: linkName,
                emoji: linkEmoji || null,
                url: url,
                id: `link_${session.buttons.length + 1}`
            });

            await showButtonsStep(interaction, session);
            break;
        case 'commandname':
            let commandName = interaction.fields.getTextInputValue('commandName');
            // Remove leading + if user included it
            if (commandName.startsWith('+')) {
                commandName = commandName.slice(1);
            }
            commandName = commandName.toLowerCase().trim();

            // Validate command name is not empty
            if (!commandName || commandName.length === 0) {
                return interaction.reply({
                    content: '❌ Please enter a valid command name (not just "+")!',
                    ephemeral: true
                });
            }

            // Save the message
            messages[commandName] = {
                title: session.title || 'No Title',
                description: session.description || 'No Description',
                color: session.color || config.defaultColor,
                image: session.image || null,
                thumbnail: session.thumbnail || null,
                footer: session.footer || null,
                repeat: session.repeat || null,
                buttons: session.buttons || [],
                createdAt: new Date().toISOString(),
                createdBy: interaction.user.id
            };

            saveData();
            userSessions.delete(userId);

            await interaction.reply({
                content: `✅ Message saved as \`+${commandName}\`!`,
                ephemeral: true
            });
            break;
    }
}

// Wizard step functions
async function showModalForStep(interaction, step) {
    const modal = new ModalBuilder()
        .setCustomId(`${step}_${interaction.user.id}`)
        .setTitle(`Set ${step.charAt(0).toUpperCase() + step.slice(1)}`);

    const input = new TextInputBuilder()
        .setCustomId(step)
        .setLabel(step === 'color' ? 'Hex Color' : step.charAt(0).toUpperCase() + step.slice(1))
        .setStyle(TextInputStyle.Short);

    switch(step) {
        case 'color':
            input.setValue('#000000');
            break;
        case 'repeat':
            input.setValue('60');
            modal.setTitle('Set Repeat Time');
            input.setLabel('Time in seconds');
            break;
    }

    modal.addComponents(new ActionRowBuilder().addComponents(input));

    await interaction.showModal(modal);
}

async function showTitleStep(interaction, session) {
    const embed = new EmbedBuilder()
        .setColor(config.defaultColor)
        .setTitle('Customise Title')
        .setDescription('Set The Title of your Message');

    const row = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId(`title_${interaction.user.id}`)
                .setLabel('Set Title')
                .setStyle(ButtonStyle.Primary)
        );

    await interaction.update({ embeds: [embed], components: [row] });
}

async function showDescriptionStep(interaction, session) {
    const embed = new EmbedBuilder()
        .setColor(config.defaultColor)
        .setTitle('Customise Description')
        .setDescription('Set Description of Custom Message');

    const row = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId(`description_${interaction.user.id}`)
                .setLabel('Set Description')
                .setStyle(ButtonStyle.Primary)
        );

    await interaction.update({ embeds: [embed], components: [row] });
}

async function showImagesStep(interaction, session) {
    const embed = new EmbedBuilder()
        .setColor(config.defaultColor)
        .setTitle('Image & Thumbnail')
        .setDescription('Set URLs or Skip');

    const row = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId(`image_${interaction.user.id}`)
                .setLabel('Image')
                .setStyle(ButtonStyle.Primary),
            new ButtonBuilder()
                .setCustomId(`thumbnail_${interaction.user.id}_1`)
                .setLabel('Thumbnail 1')
                .setStyle(ButtonStyle.Primary),
            new ButtonBuilder()
                .setCustomId(`skip_${interaction.user.id}_images`)
                .setLabel('Skip')
                .setStyle(ButtonStyle.Secondary)
        );

    await interaction.update({ embeds: [embed], components: [row] });
}

async function showFooterStep(interaction, session) {
    const embed = new EmbedBuilder()
        .setColor(config.defaultColor)
        .setTitle('Customise Footer')
        .setDescription('Set Footer or Skip')
        .setImage(config.images.footerImage)
        .setThumbnail(config.images.thumbnail);

    const row = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId(`footer_${interaction.user.id}`)
                .setLabel('Set Footer')
                .setStyle(ButtonStyle.Primary),
            new ButtonBuilder()
                .setCustomId(`skip_${interaction.user.id}_footer`)
                .setLabel('Skip')
                .setStyle(ButtonStyle.Secondary)
        );

    await interaction.update({ embeds: [embed], components: [row] });
}

async function showRepeatStep(interaction, session) {
    const embed = new EmbedBuilder()
        .setColor(config.defaultColor)
        .setTitle('Repeat?')
        .setDescription('Would you like this message to repeat?')
        .setImage(config.images.footerImage)
        .setThumbnail(config.images.thumbnail);

    const row = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId(`repeat_${interaction.user.id}`)
                .setLabel('Yes')
                .setStyle(ButtonStyle.Success),
            new ButtonBuilder()
                .setCustomId(`skip_${interaction.user.id}_repeat`)
                .setLabel('No')
                .setStyle(ButtonStyle.Secondary)
        );

    await interaction.update({ embeds: [embed], components: [row] });
}

async function showButtonsStep(interaction, session) {
    const embed = new EmbedBuilder()
        .setColor(config.defaultColor)
        .setTitle('Customise Buttons')
        .setDescription(`Current: ${session.buttons?.length || 0}`)
        .setImage(config.images.footerImage)
        .setThumbnail(config.images.thumbnail);

    const row = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId(`addbutton_${interaction.user.id}`)
                .setLabel(`Add Button ${(session.buttons?.length || 0) + 1}`)
                .setStyle(ButtonStyle.Primary),
            new ButtonBuilder()
                .setCustomId(`addlink_${interaction.user.id}`)
                .setLabel(`Add Link ${(session.buttons?.length || 0) + 1}`)
                .setStyle(ButtonStyle.Primary),
            new ButtonBuilder()
                .setCustomId(`submit_${interaction.user.id}`)
                .setLabel('Submit')
                .setStyle(ButtonStyle.Success)
        );

    await interaction.update({ embeds: [embed], components: [row] });
}

async function handleWizardAction(interaction, action, session) {
    switch(action) {
        case 'image':
            session.image = await promptForInput(interaction, 'image', 'Image URL', 'Enter image URL');
            break;
        case 'thumbnail':
            const thumbNum = parseInt(interaction.customId.split('_')[2]);
            session.thumbnail = session.thumbnail || [];
            session.thumbnail[thumbNum - 1] = await promptForInput(interaction, 'thumbnail', 'Thumbnail URL', 'Enter thumbnail URL');

            if (thumbNum < 3) {
                const embed = new EmbedBuilder()
                    .setColor(config.defaultColor)
                    .setTitle('Image & Thumbnail')
                    .setDescription('Set URLs or Skip');

                const row = new ActionRowBuilder()
                    .addComponents(
                        new ButtonBuilder()
                            .setCustomId(`image_${interaction.user.id}`)
                            .setLabel('Image')
                            .setStyle(ButtonStyle.Primary),
                        new ButtonBuilder()
                            .setCustomId(`thumbnail_${interaction.user.id}_${thumbNum + 1}`)
                            .setLabel(`Thumbnail ${thumbNum + 1}`)
                            .setStyle(ButtonStyle.Primary),
                        new ButtonBuilder()
                            .setCustomId(`skip_${interaction.user.id}_images`)
                            .setLabel('Skip')
                            .setStyle(ButtonStyle.Secondary)
                    );

                await interaction.update({ embeds: [embed], components: [row] });
            } else {
                await showFooterStep(interaction, session);
            }
            break;
        case 'skip':
            const skipType = interaction.customId.split('_')[2];
            if (skipType === 'images') {
                await showFooterStep(interaction, session);
            } else if (skipType === 'footer') {
                await showRepeatStep(interaction, session);
            } else if (skipType === 'repeat') {
                await showButtonsStep(interaction, session);
            }
            break;
        case 'addbutton':
            await showButtonModal(interaction);
            break;
        case 'addlink':
            await showLinkModal(interaction);
            break;
        case 'submit':
            await showCommandNameModal(interaction);
            break;
    }
}

async function promptForInput(interaction, type, label, placeholder) {
    const modal = new ModalBuilder()
        .setCustomId(`${type}_${interaction.user.id}`)
        .setTitle(`Set ${label}`);

    const input = new TextInputBuilder()
        .setCustomId(type)
        .setLabel(label)
        .setPlaceholder(placeholder)
        .setStyle(TextInputStyle.Short);

    modal.addComponents(new ActionRowBuilder().addComponents(input));

    await interaction.showModal(modal);

    // This is a simplified version - in production you'd need to handle the modal response
    return new Promise((resolve) => {
        // You'd set up an event listener for the modal response
        // For now, we'll return a placeholder
        resolve('');
    });
}

async function showButtonModal(interaction) {
    const modal = new ModalBuilder()
        .setCustomId(`button_${interaction.user.id}`)
        .setTitle('Add Button');

    const buttonName = new TextInputBuilder()
        .setCustomId('buttonName')
        .setLabel('Button Name')
        .setStyle(TextInputStyle.Short);

    const emoji = new TextInputBuilder()
        .setCustomId('emoji')
        .setLabel('Emoji')
        .setStyle(TextInputStyle.Short)
        .setRequired(false);

    const description = new TextInputBuilder()
        .setCustomId('description')
        .setLabel('Description')
        .setStyle(TextInputStyle.Paragraph);

    const color = new TextInputBuilder()
        .setCustomId('color')
        .setLabel('Color (grey/blue/green/red)')
        .setStyle(TextInputStyle.Short);

    modal.addComponents(
        new ActionRowBuilder().addComponents(buttonName),
        new ActionRowBuilder().addComponents(emoji),
        new ActionRowBuilder().addComponents(description),
        new ActionRowBuilder().addComponents(color)
    );

    await interaction.showModal(modal);
}

async function showLinkModal(interaction) {
    const modal = new ModalBuilder()
        .setCustomId(`link_${interaction.user.id}`)
        .setTitle('Add Link Button');

    const buttonName = new TextInputBuilder()
        .setCustomId('buttonName')
        .setLabel('Button Name')
        .setStyle(TextInputStyle.Short);

    const emoji = new TextInputBuilder()
        .setCustomId('emoji')
        .setLabel('Emoji')
        .setStyle(TextInputStyle.Short)
        .setRequired(false);

    const url = new TextInputBuilder()
        .setCustomId('url')
        .setLabel('URL')
        .setStyle(TextInputStyle.Short)
        .setValue('https://example.com');

    modal.addComponents(
        new ActionRowBuilder().addComponents(buttonName),
        new ActionRowBuilder().addComponents(emoji),
        new ActionRowBuilder().addComponents(url)
    );

    await interaction.showModal(modal);
}

async function showCommandNameModal(interaction) {
    const modal = new ModalBuilder()
        .setCustomId(`commandname_${interaction.user.id}`)
        .setTitle('Set Command Name');

    const commandName = new TextInputBuilder()
        .setCustomId('commandName')
        .setLabel('Command Name')
        .setStyle(TextInputStyle.Short)
        .setValue('+');

    modal.addComponents(new ActionRowBuilder().addComponents(commandName));

    await interaction.showModal(modal);
}

// Check if user bypasses blacklist
function hasBypass(message, blacklist) {
    if (blacklist.bypassUsers.includes(message.author.id)) return true;
    if (blacklist.bypassChannels.includes(message.channel.id)) return true;
    if (message.member && message.member.roles.cache.some(role => blacklist.bypassRoles.includes(role.id))) return true;
    if (message.member && message.member.permissions.has('Administrator')) return true;
    return false;
}

// Handle all messages
client.on('messageCreate', async message => {
    if (message.author.bot) return;
    if (!message.guild) return;

    const blacklist = loadBlacklist();
    const messageContent = message.content.toLowerCase();

    if (!hasBypass(message, blacklist)) {
        const hasLink = urlRegex.test(message.content);
        urlRegex.lastIndex = 0;

        if (hasLink) {
            try {
                await message.delete();
                const embed = new EmbedBuilder()
                    .setColor('#000001')
                    .setTitle('🚫 Links Not Allowed')
                    .setDescription("Why'd you do that?")
                    .setImage('https://cdn.discordapp.com/attachments/1442093639822999572/1446522983764992112/b98f92b7f5d87aca06a9e1a2bdbec068.gif');
                try {
                    await message.author.send({ embeds: [embed] });
                } catch (e) {
                    console.error('Could not DM user:', e);
                }
                return;
            } catch (error) {
                console.error('Error handling link:', error);
            }
        }

        for (const word of blacklist.words) {
            if (messageContent.includes(word.toLowerCase())) {
                try {
                    await message.delete();
                    const embed = new EmbedBuilder()
                        .setColor('#000001')
                        .setTitle('🚫 Blacklisted Word Detected')
                        .setDescription("Your message contained a blacklisted word and was removed.")
                        .setImage('https://cdn.discordapp.com/attachments/1442093639822999572/1446522983764992112/b98f92b7f5d87aca06a9e1a2bdbec068.gif');
                    try {
                        await message.author.send({ embeds: [embed] });
                    } catch (e) {
                        console.error('Could not DM user:', e);
                    }
                    return;
                } catch (error) {
                    console.error('Error handling blacklisted word:', error);
                }
            }
        }
    }

    if (!message.content.startsWith('+')) return;

    const commandName = message.content.slice(1).split(' ')[0].toLowerCase();
    const msgData = messages[commandName];
    if (!msgData) return;

    const embed = new EmbedBuilder();
    if (msgData.color) embed.setColor(msgData.color);
    if (msgData.title) embed.setTitle(msgData.title);
    if (msgData.description) embed.setDescription(msgData.description);
    if (msgData.image) embed.setImage(msgData.image);
    if (msgData.thumbnail) embed.setThumbnail(msgData.thumbnail);
    if (msgData.footer) embed.setFooter({ text: msgData.footer });

    const components = [];
    if (msgData.buttons && msgData.buttons.length > 0) {
        const row = new ActionRowBuilder();
        for (const btn of msgData.buttons) {
            if (btn.type === 'link') {
                const button = new ButtonBuilder()
                    .setLabel(btn.label)
                    .setStyle(ButtonStyle.Link)
                    .setURL(btn.url);
                if (btn.emoji) button.setEmoji(btn.emoji);
                row.addComponents(button);
            } else {
                const button = new ButtonBuilder()
                    .setCustomId(btn.id)
                    .setLabel(btn.label)
                    .setStyle(getButtonStyleFromColor(btn.color));
                if (btn.emoji) button.setEmoji(btn.emoji);
                row.addComponents(button);
            }
        }
        components.push(row);
    }

    try {
        await message.channel.send({ embeds: [embed], components });
    } catch (error) {
        console.error('Error sending custom message:', error);
    }
});

// Helper function to get button style from color name
function getButtonStyleFromColor(color) {
    switch(color?.toLowerCase()) {
        case 'grey': return ButtonStyle.Secondary;
        case 'green': return ButtonStyle.Success;
        case 'red': return ButtonStyle.Danger;
        case 'blue': return ButtonStyle.Primary;
        default: return ButtonStyle.Primary;
    }
}

// Login to Discord
client.login(process.env.DISCORD_TOKEN);