const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');
const fs = require('fs');
const path = require('path');

const blacklistPath = path.join(__dirname, '..', 'data', 'blacklist.json');
const autopurgePath = path.join(__dirname, '..', 'data', 'autopurge.json');

function loadBlacklist() {
    if (!fs.existsSync(blacklistPath)) {
        fs.writeFileSync(blacklistPath, JSON.stringify({ words: [], bypassUsers: [], bypassRoles: [], bypassChannels: [] }));
    }
    return JSON.parse(fs.readFileSync(blacklistPath, 'utf8'));
}

function saveBlacklist(data) {
    fs.writeFileSync(blacklistPath, JSON.stringify(data, null, 2));
}

function loadAutopurge() {
    if (!fs.existsSync(autopurgePath)) {
        fs.writeFileSync(autopurgePath, JSON.stringify({}));
    }
    return JSON.parse(fs.readFileSync(autopurgePath, 'utf8'));
}

function saveAutopurge(data) {
    fs.writeFileSync(autopurgePath, JSON.stringify(data, null, 2));
}

const blacklistWordCommand = {
    data: new SlashCommandBuilder()
        .setName('blacklistword')
        .setDescription('Add a blacklisted word')
        .addStringOption(option =>
            option.setName('word')
                .setDescription('The word to blacklist')
                .setRequired(true))
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

    async execute(interaction) {
        const word = interaction.options.getString('word').toLowerCase();
        const blacklist = loadBlacklist();

        if (blacklist.words.includes(word)) {
            return interaction.reply({ content: `❌ "${word}" is already blacklisted!`, ephemeral: true });
        }

        blacklist.words.push(word);
        saveBlacklist(blacklist);

        const embed = new EmbedBuilder()
            .setColor('#00ff00')
            .setTitle('✅ Word Blacklisted')
            .setDescription(`**"${word}"** has been added to the blacklist.`);

        await interaction.reply({ embeds: [embed], ephemeral: true });
    }
};

const unblacklistWordCommand = {
    data: new SlashCommandBuilder()
        .setName('unblacklistword')
        .setDescription('Remove a blacklisted word')
        .addStringOption(option =>
            option.setName('word')
                .setDescription('The word to remove from blacklist')
                .setRequired(true))
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

    async execute(interaction) {
        const word = interaction.options.getString('word').toLowerCase();
        const blacklist = loadBlacklist();

        const index = blacklist.words.indexOf(word);
        if (index === -1) {
            return interaction.reply({ content: `❌ "${word}" is not blacklisted!`, ephemeral: true });
        }

        blacklist.words.splice(index, 1);
        saveBlacklist(blacklist);

        const embed = new EmbedBuilder()
            .setColor('#00ff00')
            .setTitle('✅ Word Removed')
            .setDescription(`**"${word}"** has been removed from the blacklist.`);

        await interaction.reply({ embeds: [embed], ephemeral: true });
    }
};

const blacklistListCommand = {
    data: new SlashCommandBuilder()
        .setName('blacklist_list')
        .setDescription('Show all blacklisted words and bypasses')
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

    async execute(interaction) {
        const blacklist = loadBlacklist();

        const usersList = blacklist.bypassUsers.length > 0 
            ? blacklist.bypassUsers.map(id => `<@${id}>`).join(', ')
            : 'None';
        const rolesList = blacklist.bypassRoles.length > 0
            ? blacklist.bypassRoles.map(id => `<@&${id}>`).join(', ')
            : 'None';
        const channelsList = blacklist.bypassChannels.length > 0
            ? blacklist.bypassChannels.map(id => `<#${id}>`).join(', ')
            : 'None';

        const embed = new EmbedBuilder()
            .setColor('#a000c8')
            .setTitle('📋 Blacklist Information')
            .setDescription(`**• Users: ${usersList}.**\n**• Roles: ${rolesList}.**\n**• Channels: ${channelsList}.**`)
            .addFields(
                { name: '🚫 Blacklisted Words', value: blacklist.words.length > 0 ? blacklist.words.map(w => `\`${w}\``).join(', ') : 'None', inline: false }
            )
            .setThumbnail('https://cdn.discordapp.com/attachments/1442093639822999572/1446523011044741161/tumblr_131417bd07c326fa8c04e35e769217e3_55caddec_500.gif');

        await interaction.reply({ embeds: [embed], ephemeral: true });
    }
};

const blacklistBypassCommand = {
    data: new SlashCommandBuilder()
        .setName('blacklist_bypass')
        .setDescription('Add bypass for blacklist')
        .addSubcommand(subcommand =>
            subcommand
                .setName('user')
                .setDescription('Add user bypass')
                .addUserOption(option =>
                    option.setName('target')
                        .setDescription('User to bypass')
                        .setRequired(true)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('role')
                .setDescription('Add role bypass')
                .addRoleOption(option =>
                    option.setName('target')
                        .setDescription('Role to bypass')
                        .setRequired(true)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('channel')
                .setDescription('Add channel bypass')
                .addChannelOption(option =>
                    option.setName('target')
                        .setDescription('Channel to bypass')
                        .setRequired(true)
                        .addChannelTypes(ChannelType.GuildText)))
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

    async execute(interaction) {
        const subcommand = interaction.options.getSubcommand();
        const blacklist = loadBlacklist();

        let targetId, targetMention, listKey;

        switch (subcommand) {
            case 'user':
                const user = interaction.options.getUser('target');
                targetId = user.id;
                targetMention = `<@${user.id}>`;
                listKey = 'bypassUsers';
                break;
            case 'role':
                const role = interaction.options.getRole('target');
                targetId = role.id;
                targetMention = `<@&${role.id}>`;
                listKey = 'bypassRoles';
                break;
            case 'channel':
                const channel = interaction.options.getChannel('target');
                targetId = channel.id;
                targetMention = `<#${channel.id}>`;
                listKey = 'bypassChannels';
                break;
        }

        if (blacklist[listKey].includes(targetId)) {
            return interaction.reply({ content: `❌ ${targetMention} already has bypass!`, ephemeral: true });
        }

        blacklist[listKey].push(targetId);
        saveBlacklist(blacklist);

        const embed = new EmbedBuilder()
            .setColor('#00ff00')
            .setTitle('✅ Bypass Added')
            .setDescription(`${targetMention} now bypasses the blacklist.`);

        await interaction.reply({ embeds: [embed], ephemeral: true });
    }
};

const blacklistRemoveBypassCommand = {
    data: new SlashCommandBuilder()
        .setName('blacklist_removebypass')
        .setDescription('Remove bypass for blacklist')
        .addSubcommand(subcommand =>
            subcommand
                .setName('user')
                .setDescription('Remove user bypass')
                .addUserOption(option =>
                    option.setName('target')
                        .setDescription('User to remove bypass')
                        .setRequired(true)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('role')
                .setDescription('Remove role bypass')
                .addRoleOption(option =>
                    option.setName('target')
                        .setDescription('Role to remove bypass')
                        .setRequired(true)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('channel')
                .setDescription('Remove channel bypass')
                .addChannelOption(option =>
                    option.setName('target')
                        .setDescription('Channel to remove bypass')
                        .setRequired(true)
                        .addChannelTypes(ChannelType.GuildText)))
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

    async execute(interaction) {
        const subcommand = interaction.options.getSubcommand();
        const blacklist = loadBlacklist();

        let targetId, targetMention, listKey;

        switch (subcommand) {
            case 'user':
                const user = interaction.options.getUser('target');
                targetId = user.id;
                targetMention = `<@${user.id}>`;
                listKey = 'bypassUsers';
                break;
            case 'role':
                const role = interaction.options.getRole('target');
                targetId = role.id;
                targetMention = `<@&${role.id}>`;
                listKey = 'bypassRoles';
                break;
            case 'channel':
                const channel = interaction.options.getChannel('target');
                targetId = channel.id;
                targetMention = `<#${channel.id}>`;
                listKey = 'bypassChannels';
                break;
        }

        const index = blacklist[listKey].indexOf(targetId);
        if (index === -1) {
            return interaction.reply({ content: `❌ ${targetMention} doesn't have bypass!`, ephemeral: true });
        }

        blacklist[listKey].splice(index, 1);
        saveBlacklist(blacklist);

        const embed = new EmbedBuilder()
            .setColor('#00ff00')
            .setTitle('✅ Bypass Removed')
            .setDescription(`${targetMention} no longer bypasses the blacklist.`);

        await interaction.reply({ embeds: [embed], ephemeral: true });
    }
};

const autoPurgeSetupCommand = {
    data: new SlashCommandBuilder()
        .setName('auto_purge_setup')
        .setDescription('Setup auto-purge for a channel')
        .addChannelOption(option =>
            option.setName('channel')
                .setDescription('Channel to auto-purge')
                .setRequired(true)
                .addChannelTypes(ChannelType.GuildText))
        .addStringOption(option =>
            option.setName('time')
                .setDescription('Time interval (e.g., 20s, 20m, 2h, 1d)')
                .setRequired(true))
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

    async execute(interaction, context) {
        const channel = interaction.options.getChannel('channel');
        const timeStr = interaction.options.getString('time');

        const timeRegex = /^(\d+)(s|m|h|d)$/i;
        const match = timeStr.match(timeRegex);

        if (!match) {
            return interaction.reply({ content: '❌ Invalid time format! Use: 20s, 20m, 2h, or 1d', ephemeral: true });
        }

        const value = parseInt(match[1]);
        const unit = match[2].toLowerCase();

        let milliseconds;
        switch (unit) {
            case 's': milliseconds = value * 1000; break;
            case 'm': milliseconds = value * 60 * 1000; break;
            case 'h': milliseconds = value * 60 * 60 * 1000; break;
            case 'd': milliseconds = value * 24 * 60 * 60 * 1000; break;
        }

        const autopurge = loadAutopurge();
        autopurge[channel.id] = {
            interval: milliseconds,
            timeString: timeStr,
            guildId: interaction.guild.id
        };
        saveAutopurge(autopurge);

        if (context && context.startAutoPurgeIntervals) {
            context.startAutoPurgeIntervals();
        }

        const embed = new EmbedBuilder()
            .setColor('#000001')
            .setTitle('✅ Auto-Purge Setup')
            .setDescription(`Auto-purge enabled for <#${channel.id}>\n\n**Interval:** ${timeStr}`);

        await interaction.reply({ embeds: [embed], ephemeral: true });
    }
};

const autoPurgeRemoveCommand = {
    data: new SlashCommandBuilder()
        .setName('auto_purge_remove')
        .setDescription('Remove auto-purge from a channel')
        .addChannelOption(option =>
            option.setName('channel')
                .setDescription('Channel to remove auto-purge from')
                .setRequired(true)
                .addChannelTypes(ChannelType.GuildText))
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

    async execute(interaction, context) {
        const channel = interaction.options.getChannel('channel');
        const autopurge = loadAutopurge();

        if (!autopurge[channel.id]) {
            return interaction.reply({ content: '❌ This channel has no auto-purge setup!', ephemeral: true });
        }

        delete autopurge[channel.id];
        saveAutopurge(autopurge);

        if (context && context.clearAutoPurgeInterval) {
            context.clearAutoPurgeInterval(channel.id);
        }

        const embed = new EmbedBuilder()
            .setColor('#000001')
            .setTitle('✅ Auto-Purge Removed')
            .setDescription(`Auto-purge disabled for <#${channel.id}>`);

        await interaction.reply({ embeds: [embed], ephemeral: true });
    }
};

module.exports = [
    blacklistWordCommand,
    unblacklistWordCommand,
    blacklistListCommand,
    blacklistBypassCommand,
    blacklistRemoveBypassCommand,
    autoPurgeSetupCommand,
    autoPurgeRemoveCommand
];

module.exports.loadBlacklist = loadBlacklist;
module.exports.loadAutopurge = loadAutopurge;
module.exports.saveAutopurge = saveAutopurge;
